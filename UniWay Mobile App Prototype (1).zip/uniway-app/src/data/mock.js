// Datos simulados (mock). Sustituir por llamadas a la API.
export const INTERESTS=[{id:'estudios',icon:'book'},{id:'info',icon:'landmark'},{id:'gente',icon:'users'},{id:'eventos',icon:'calendar'},{id:'deportes',icon:'trophy'},{id:'empleo',icon:'briefcase'}];

export const PLACES=[
  {id:'norte',name:'Edificio Norte',short:'Edificio Norte',x:150,y:22,w:150,h:88,interest:null,icon:'building',desc:'Informática y Telecomunicaciones · Aulas 0.1–3.8',walk:'4 min'},
  {id:'magna',name:'Aula Magna',short:'Aula Magna',x:20,y:36,w:90,h:84,interest:'eventos',icon:'calendar',desc:'Viernes 25 · 21:00 · Fiesta de bienvenida Erasmus',walk:'4 min'},
  {id:'biblio',name:'Biblioteca',short:'Biblioteca',x:20,y:196,w:96,h:92,interest:'estudios',icon:'book',desc:'Abierta hasta las 23:00 · Planta 3, zona silencio',walk:'Estás aquí'},
  {id:'cafe',name:'Cafetería Central',short:'Cafetería',x:150,y:166,w:78,h:72,interest:'gente',icon:'coffee',desc:'Abierta · menú del día 6,50 €',walk:'2 min'},
  {id:'rect',name:'Rectorado',short:'Rectorado',x:256,y:162,w:98,h:74,interest:'info',icon:'landmark',desc:'Secretaría y tarjeta universitaria · 9:00–14:00',walk:'5 min'},
  {id:'poli',name:'Polideportivo',short:'Polideportivo',x:256,y:278,w:98,h:86,interest:'deportes',icon:'trophy',desc:'Vóley mixto · martes y jueves a las 20:00',walk:'6 min'},
  {id:'empleo',name:'Centro de Empleo',short:'Empleo',x:150,y:278,w:78,h:52,interest:'empleo',icon:'briefcase',desc:'1 de octubre · Feria de prácticas tech',walk:'3 min'},
];

export const REC={
  gente:{title:'Intercambio de idiomas ES · IT · FR',meta:'Martes 29 · 18:00 · Cafetería Central',place:'cafe'},
  estudios:{title:'Grupo de estudio de C++ para 2º',meta:'Miércoles · 17:00 · Biblioteca, sala 3',place:'biblio'},
  deportes:{title:'Vóley mixto: faltan 2 jugadores',meta:'Martes y jueves · 20:00 · Polideportivo',place:'poli'},
  eventos:{title:'Fiesta de bienvenida Erasmus',meta:'Viernes 25 · 21:00 · Aula Magna',place:'magna'},
  info:{title:'Recoge tu tarjeta universitaria',meta:'Rectorado · planta baja · 9:00–14:00',place:'rect'},
  empleo:{title:'Feria de prácticas tech',meta:'1 de octubre · Centro de Empleo',place:'empleo'},
};

export const AV=[['#E4E1FC','#2A1FA8'],['#FFE3DE','#A8321F'],['#D9F1EC','#0B6B62'],['#FBEFD3','#7A5000']];

export const POSTS=[
  {id:1,name:'Giulia Romano',handle:'@giulia.rm',erasmus:true,country:'Italia',fac:'informatica',facLabel:'Fac. Informática',time:'12 min',av:1,likes:24,text:'¿Alguien de 2º de Informática para montar un grupo de estudio de C++? Busco gente para repasar punteros antes del primer parcial. Yo pongo el café.',comments:[{name:'Marcos Gil',initials:'MG',text:'¡Me apunto! Martes por la tarde en la biblio me va perfecto.'}]},
  {id:2,name:'Marcos Gil',handle:'@marcosgil',erasmus:false,fac:'informatica',facLabel:'Fac. Informática',time:'1 h',av:0,likes:58,text:'Aviso: la biblioteca abre hasta las 23:00 toda la semana de exámenes. Planta 3 = silencio total, planta 1 para trabajar en grupo.',comments:[]},
  {id:3,name:'Léa Dubois',handle:'@lea.db',erasmus:true,country:'Francia',fac:'letras',facLabel:'Fac. Letras',time:'2 h',av:2,likes:41,text:'Intercambio de idiomas en la Cafetería Central: francés, inglés, italiano y español. El nivel da igual, las ganas no.',event:{mon:'Sep',day:'29',title:'Intercambio de idiomas',where:'18:00 · Cafetería Central'},comments:[]},
  {id:4,name:'Paula Ortega',handle:'@paulaort',erasmus:false,fac:'deporte',facLabel:'Fac. Ciencias del Deporte',time:'4 h',av:3,likes:17,text:'Nos faltan dos personas para el equipo mixto de vóley. Entrenamos martes y jueves en el Polideportivo, cualquier nivel.',comments:[]},
  {id:5,name:'Jonas Becker',handle:'@jonas.bk',erasmus:true,country:'Alemania',fac:'informatica',facLabel:'Fac. Informática',time:'1 d',av:1,likes:89,text:'Tip para Erasmus: la tarjeta universitaria se recoge en el Rectorado, planta baja. Lleva el pasaporte y el Learning Agreement firmado.',comments:[]},
];

export const DEMO={name:'Lucía',study:'Ingeniería Informática',kind:'local',year:'2º',group:'B',shift:'am',interests:['estudios','gente','deportes'],freq:'w'};

export const EMPTY={name:'',study:'',kind:'local',year:'',group:'',shift:'am',interests:[],freq:'w'};

export const ROUTE=[[129,256],[129,141],[205,141],[205,114]];

export const OUT_STEPS=[
  {t:'Sal de la Biblioteca hacia el norte',d:'170 m',icon:'arrowUp'},
  {t:'Gira a la derecha en Av. Central',d:'115 m',icon:'turnRight'},
  {t:'Entra en el Edificio Norte por la puerta principal',d:'40 m',icon:'door'},
];

export const FLOORS={
  0:{rooms:[
    {l:'0.1',s:'Conserjería',x:22,y:22,w:96,h:150,k:'room'},{l:'0.2',s:'Sala de estudio',x:124,y:22,w:110,h:150,k:'room'},{l:'0.3',s:'Secretaría',x:240,y:22,w:108,h:150,k:'room'},
    {l:'B',s:'Escalera',x:22,y:230,w:70,h:70,k:'stairs'},{l:'',s:'Ascensor',x:22,y:306,w:70,h:58,k:'stairs'},
    {l:'0.4',s:'Aula',x:100,y:230,w:58,h:134,k:'room'},{l:'',s:'Entrada',x:164,y:222,w:44,h:156,k:'hall'},
    {l:'0.5',s:'Aula',x:214,y:230,w:70,h:134,k:'room'},{l:'WC',s:'Aseos',x:290,y:230,w:58,h:134,k:'wc'}],
    route:[[186,366],[186,201],[57,201],[57,262]]},
  1:{rooms:[
    {l:'1.1',s:'Aula',x:22,y:22,w:76,h:150,k:'room'},{l:'1.2',s:'Aula',x:104,y:22,w:76,h:150,k:'room'},{l:'1.3',s:'Seminario',x:186,y:22,w:76,h:150,k:'room'},{l:'1.4',s:'Aula',x:268,y:22,w:80,h:150,k:'room'},
    {l:'B',s:'Escalera',x:22,y:230,w:70,h:70,k:'stairs'},{l:'',s:'Ascensor',x:22,y:306,w:70,h:58,k:'stairs'},
    {l:'1.5',s:'Laboratorio',x:100,y:230,w:120,h:134,k:'room'},{l:'1.6',s:'Aula',x:226,y:230,w:62,h:134,k:'room'},{l:'WC',s:'Aseos',x:294,y:230,w:54,h:134,k:'wc'}],route:null},
  2:{rooms:[
    {l:'2.1',s:'Aula',x:22,y:22,w:76,h:150,k:'room'},{l:'2.2',s:'Aula',x:104,y:22,w:76,h:150,k:'room'},{l:'2.3',s:'Seminario',x:186,y:22,w:76,h:150,k:'room'},{l:'2.4',s:'Tu clase',x:268,y:22,w:80,h:150,k:'dest'},
    {l:'B',s:'Escalera',x:22,y:230,w:70,h:70,k:'stairs'},{l:'',s:'Ascensor',x:22,y:306,w:70,h:58,k:'stairs'},
    {l:'2.5',s:'Laboratorio',x:100,y:230,w:120,h:134,k:'room'},{l:'2.6',s:'Aula',x:226,y:230,w:62,h:134,k:'room'},{l:'WC',s:'Aseos',x:294,y:230,w:54,h:134,k:'wc'}],
    route:[[57,262],[57,201],[308,201],[308,166]]},
};

export const IN_STEPS=[
  {t:'Entra por la puerta principal',d:'Planta 0'},
  {t:'Gira a la izquierda hacia la Escalera B',d:'25 m'},
  {t:'Sube a la 2ª planta',d:'Escalera B'},
  {t:'Sigue el pasillo principal hasta el fondo',d:'40 m'},
  {t:'Aula 2.4 · última puerta a la izquierda',d:'Llegada'},
];

export const ROOM_STYLE={
  room:{bg:'#FFFFFF',bd:'1px solid #DAD6E8',fg:'#16142B'},
  dest:{bg:'#E4E1FC',bd:'2px solid #3D2FD6',fg:'#2A1FA8'},
  stairs:{bg:'#FBEFD3',bd:'1px solid #EBD9A8',fg:'#7A5000'},
  wc:{bg:'#ECEAF3',bd:'1px solid #DAD6E8',fg:'#6B6883'},
  hall:{bg:'#FFFFFF',bd:'none',fg:'#6B6883'},
};

export const CAFE={
  hours:[{d:'Lunes a viernes',h:'7:30 – 20:00',today:true},{d:'Sábado',h:'9:00 – 14:00'},{d:'Domingo y festivos',h:'Cerrado'}],
  tabs:[{id:'menu',l:'Menú del día'},{id:'bocatas',l:'Bocadillos'},{id:'bebidas',l:'Bebidas'},{id:'dulces',l:'Dulces'}],
  items:{
    menu:[{n:'Menú completo',d:'Primero, segundo, postre, pan y bebida · 13:00–16:00',p:'6,50 €',hl:true},{n:'Medio menú',d:'Un plato, pan y bebida',p:'4,80 €'},{n:'Primeros',d:'Lentejas estofadas · Ensalada de pasta · Crema de calabaza',p:'Incluido'},{n:'Segundos',d:'Pollo al horno con patatas · Merluza a la plancha · Curry de garbanzos (vegano)',p:'Incluido'},{n:'Postres',d:'Fruta de temporada · Yogur · Flan casero',p:'Incluido'}],
    bocatas:[{n:'Tortilla de patatas',d:'Pan de barra, con o sin cebolla',p:'3,20 €'},{n:'Jamón serrano con tomate',d:'Pan de cristal',p:'3,80 €'},{n:'Lomo con queso',d:'A la plancha',p:'3,60 €'},{n:'Vegetal',d:'Lechuga, tomate, huevo y espárragos',p:'3,00 €'},{n:'Pepito de ternera',d:'Con pimientos asados',p:'4,20 €'}],
    bebidas:[{n:'Café solo',d:'',p:'1,10 €'},{n:'Café con leche',d:'Leche de avena o soja sin coste extra',p:'1,30 €'},{n:'Cappuccino',d:'',p:'1,70 €'},{n:'Cola Cao',d:'',p:'1,40 €'},{n:'Zumo de naranja natural',d:'Recién exprimido',p:'2,20 €'},{n:'Agua 50 cl',d:'',p:'0,90 €'},{n:'Refresco',d:'Lata 33 cl',p:'1,60 €'}],
    dulces:[{n:'Croissant',d:'',p:'1,20 €'},{n:'Napolitana de chocolate',d:'',p:'1,40 €'},{n:'Tostada con tomate y aceite',d:'Pan de pueblo',p:'1,80 €'},{n:'Muffin',d:'Arándanos o chocolate',p:'1,60 €'}],
  },
};

export const CHATS=[
  {id:'giulia',name:'Giulia Romano',sub:'Erasmus · Italia',av:1,online:true,unread:2,when:'11:24',msgs:[
    {me:false,text:'Ciao Lucía! Soy Giulia, la del post del grupo de C++',t:'11:20'},
    {me:true,text:'¡Hola Giulia! Sí, me apunto seguro',t:'11:21'},
    {me:false,text:'Perfecto. Traigo mis apuntes de punteros',t:'11:23'},
    {me:false,text:'¿Quedamos a las 17 en la biblio?',t:'11:24'}],
    replies:[{text:'Perfetto! Nos vemos en la planta 1'},{text:'Yo llevo el café, tú las dudas'},{text:'Grazie mille, ¡hasta luego!'}]},
  {id:'grupo',name:'2º B · Informática',sub:'32 miembros',group:true,av:0,unread:5,when:'11:02',msgs:[
    {me:false,from:'Marcos',text:'¿Alguien tiene los apuntes de Discreta del lunes?',t:'10:58'},
    {me:false,from:'Sara',text:'Yo, luego los subo al drive',t:'11:00'},
    {me:false,from:'Marcos',text:'Crack. ¿Y el ejercicio 4 de C++ os compila?',t:'11:02'}],
    replies:[{from:'Sara',text:'A mí sí, te faltará el #include <vector>'},{from:'Marcos',text:'Era eso, gracias'},{from:'Iván',text:'¿Alguien baja a la cafetería antes de clase?'}]},
  {id:'lea',name:'Léa Dubois',sub:'Erasmus · Francia',av:2,online:true,unread:0,when:'10:15',msgs:[
    {me:true,text:'Hola Léa, ¿el intercambio es para cualquier nivel?',t:'10:10'},
    {me:false,text:'¡Sí! Hay mesas por idioma y nivel',t:'10:14'},
    {me:false,text:'Merci! Nos vemos el martes en el intercambio',t:'10:15'}],
    replies:[{text:'Super ! Tráete a quien quieras'},{text:'À mardi !'}]},
  {id:'marcos',name:'Marcos Gil',sub:'2º B · Informática',av:0,unread:0,when:'Ayer',msgs:[
    {me:false,text:'¿Hiciste la práctica 1?',t:'Ayer'},
    {me:true,text:'Casi, me falta el makefile',t:'Ayer'},
    {me:false,text:'Te paso el enlace del repo de la práctica',t:'Ayer'}],
    replies:[{text:'Ahí lo tienes, mira la carpeta /src'},{text:'Luego lo vemos en clase'}]},
  {id:'paula',name:'Paula Ortega',sub:'Ciencias del Deporte',av:3,unread:1,when:'Lun',msgs:[
    {me:false,text:'¿Te animas al vóley el martes? Nos falta gente',t:'Lun'}],
    replies:[{text:'¡Genial! A las 20:00 en el Polideportivo'},{text:'Trae calzado de interior'}]},
  {id:'jonas',name:'Jonas Becker',sub:'Erasmus · Alemania',av:1,online:true,unread:0,when:'Lun',msgs:[
    {me:true,text:'¿Pudiste recoger la tarjeta?',t:'Lun'},
    {me:false,text:'Danke! Ya tengo la tarjeta universitaria',t:'Lun'}],
    replies:[{text:'Ahora a por el abono de transporte'},{text:'Tschüss!'}]},
];

export const SCHEDULE={
  1:[{t:'09:00',e:'10:30',title:'Matemática Discreta',place:'Aula 1.2 · Ed. Norte'},{t:'12:00',e:'13:30',title:'Desarrollo en C++',place:'Aula 2.4 · Ed. Norte'}],
  2:[{t:'09:00',e:'10:30',title:'Bases de Datos',place:'Aula 1.6 · Ed. Norte'},{t:'11:00',e:'12:30',title:'Redes',place:'Lab 1.5 · Ed. Norte'}],
  3:[{t:'09:00',e:'10:30',title:'Matemática Discreta',place:'Aula 1.2 · Ed. Norte'},{t:'12:00',e:'13:30',title:'Desarrollo en C++',place:'Aula 2.4 · Ed. Norte'}],
  4:[{t:'09:00',e:'10:30',title:'Bases de Datos',place:'Aula 1.6 · Ed. Norte'},{t:'12:00',e:'13:30',title:'Desarrollo en C++',place:'Aula 2.4 · Ed. Norte'}],
  5:[{t:'10:00',e:'11:30',title:'Redes',place:'Lab 1.5 · Ed. Norte'}],
};

export const EVENTS={
  '2026-9-25':[{t:'21:00',e:'',title:'Fiesta de bienvenida Erasmus',place:'Aula Magna',type:'evento'}],
  '2026-9-29':[{t:'18:00',e:'20:00',title:'Intercambio de idiomas',place:'Cafetería Central',type:'evento'},{t:'20:00',e:'21:30',title:'Vóley mixto',place:'Polideportivo',type:'evento'}],
  '2026-9-30':[{t:'14:00',e:'',title:'Fin de plazo: matrícula de optativas',place:'Secretaría virtual',type:'evento'}],
  '2026-10-1':[{t:'10:00',e:'14:00',title:'Feria de prácticas tech',place:'Centro de Empleo',type:'evento'}],
  '2026-10-9':[{t:'12:00',e:'14:00',title:'Parcial de Desarrollo en C++',place:'Aula 2.4 · Ed. Norte',type:'examen'}],
  '2026-10-16':[{t:'09:00',e:'11:00',title:'Parcial de Matemática Discreta',place:'Aula 1.2 · Ed. Norte',type:'examen'}],
};

export const TYPES={
  clase:{label:'Clase',bg:'#E4E1FC',fg:'#2A1FA8',dot:'#3D2FD6',icon:'cap'},
  examen:{label:'Examen',bg:'#FFE3DE',fg:'#A8321F',dot:'#E5412B',icon:'flag'},
  evento:{label:'Evento',bg:'#D9F1EC',fg:'#0B6B62',dot:'#0B8F7F',icon:'calendar'},
  estudio:{label:'Estudio',bg:'#FBEFD3',fg:'#7A5000',dot:'#D99A00',icon:'book'},
};
