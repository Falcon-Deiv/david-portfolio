import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Clock, DoorOpen, Layers, Map as MapIcon, Navigation, Plus, X } from 'lucide-react';
import { PLACES, ROUTE, OUT_STEPS, FLOORS, IN_STEPS, ROOM_STYLE } from '../data/mock.js';
import { Icon } from '../lib/icons.jsx';
import { abbr } from '../lib/dates.js';
import CafeSheet from './CafeSheet.jsx';
import AddClassSheet from './AddClassSheet.jsx';

// Lienzo lógico del mapa (coordenadas de data/mock.js). Se escala en %.
const W = 370, H = 380;
const box = (x, y, w, h) => ({ left: `${(x / W) * 100}%`, top: `${(y / H) * 100}%`, width: `${(w / W) * 100}%`, height: `${(h / H) * 100}%` });
const pt = (x, y) => ({ left: `${(x / W) * 100}%`, top: `${(y / H) * 100}%` });

const ROUTE_STAGE_MS = [4600, 7700, 9000]; // cambios de instrucción mientras el punto avanza
const WALK_SECONDS = 9;
const ease = [0.25, 0.1, 0.25, 1];

export default function Map({ t, profile, cls, minutesLeft, flash, routeRequested, onRouteStarted, myClasses, setMyClasses }) {
  const [mode, setMode] = useState('campus');       // campus | route | indoor
  const [routeStage, setRouteStage] = useState(0);  // 0-2 pasos, 3 = en la puerta
  const [indoorStage, setIndoorStage] = useState(0); // 0 = P0 → escalera, 1 = P2 → aula, 2 = llegada
  const [viewFloor, setViewFloor] = useState(0);
  const [selected, setSelected] = useState(null);
  const [sheet, setSheet] = useState(null);         // 'cafe' | 'add' | null
  const timers = useRef([]);

  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };
  useEffect(() => clearTimers, []);

  const startRoute = () => {
    clearTimers();
    setMode('route'); setRouteStage(0); setSelected(null);
    ROUTE_STAGE_MS.forEach((ms, i) => timers.current.push(setTimeout(() => {
      setRouteStage(i + 1);
      if (i === 2) flash('Estás en la entrada del Edificio Norte');
    }, ms)));
  };
  const enterBuilding = () => { clearTimers(); setMode('indoor'); setIndoorStage(0); setViewFloor(0); };
  const indoorNext = () => {
    if (indoorStage === 0) { setIndoorStage(1); setViewFloor(2); }
    else if (indoorStage === 1) { setIndoorStage(2); flash('Has llegado a tu clase'); }
    else exit();
  };
  const exit = () => { clearTimers(); setMode('campus'); setRouteStage(0); setIndoorStage(0); };

  // Viene de tocar la notificación
  useEffect(() => { if (routeRequested) { startRoute(); onRouteStarted(); } }, [routeRequested]);

  const onPlace = (p) => {
    if (mode !== 'campus') return;
    if (p.id === 'cafe') { setSheet('cafe'); return; }
    setSelected((s) => (s === p.id ? null : p.id));
  };

  const stageFloor = indoorStage === 0 ? 0 : 2;
  const banner = getBanner({ mode, routeStage, indoorStage, cls, minutesLeft });
  const steps = mode === 'route'
    ? OUT_STEPS.map((s, i) => ({ ...s, done: i < routeStage, cur: i === routeStage }))
    : IN_STEPS.map((s, i) => { const cur = [1, 3, 5][indoorStage]; return { ...s, icon: i === 2 ? 'layers' : 'nav', done: i < cur, cur: i === cur }; });
  const sel = PLACES.find((p) => p.id === selected);

  return (
    <div className="px-4 pt-[58px] flex flex-col gap-3">
      <header className="flex items-end justify-between gap-3 px-1">
        <div>
          <p className="m-0 text-[13px] font-semibold text-muted">Campus Norte · {profile.study}</p>
          <h1 className="m-0 font-display text-[30px] font-bold tracking-tight leading-tight">{t.nMap}</h1>
        </div>
        <span className="flex items-center gap-1.5 h-8 px-3 rounded-full bg-white border border-line text-xs font-bold text-body">
          <span className="w-2 h-2 rounded-full bg-brand" />
          {mode === 'route' ? 'En camino' : mode === 'indoor' ? `Ed. Norte · P${viewFloor}` : 'Biblioteca'}
        </span>
      </header>

      {/* Próxima clase (vinculada al onboarding) */}
      <section className="relative overflow-hidden bg-brand text-white rounded-3xl p-4 flex flex-col gap-2.5">
        <div className="absolute w-[170px] h-[170px] rounded-full border-[26px] border-white/10 -right-[60px] -top-[70px]" />
        <div className="relative flex items-center justify-between gap-2">
          <span className="text-xs font-extrabold tracking-wider uppercase text-white/80">Próxima clase · {profile.year} {profile.group}</span>
          <span className="flex items-center gap-1.5 h-7 px-2.5 rounded-full bg-coral text-ink text-xs font-extrabold"><Clock size={14} />{minutesLeft > 0 ? `En ${minutesLeft} min` : 'Ahora'}</span>
        </div>
        <h2 className="relative m-0 font-display text-[25px] font-bold leading-tight tracking-tight">{cls.subject}</h2>
        <p className="relative m-0 text-sm leading-snug text-white/90">{cls.room}, {cls.building} ({cls.floor}). A las 12:00 · empieza en {minutesLeft} min.</p>
        {mode === 'campus' ? (
          <motion.button whileTap={{ scale: 0.98 }} onClick={startRoute} className="relative h-12 rounded-[15px] bg-coral text-ink text-[15px] font-extrabold flex items-center justify-center gap-2">
            <Navigation size={18} strokeWidth={2.5} /> Iniciar ruta a mi clase
          </motion.button>
        ) : (
          <div className="relative flex items-center justify-between gap-2.5">
            <span className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-[10px] bg-white/15 text-xs font-bold">
              {mode === 'indoor' ? <Layers size={14} /> : <Navigation size={14} />}
              {mode === 'indoor' ? 'Plano interior · Edificio Norte' : 'Ruta exterior · 285 m'}
            </span>
            <button onClick={exit} className="h-[34px] px-3 rounded-[11px] border-[1.5px] border-white/50 text-[13px] font-bold">Salir de la ruta</button>
          </div>
        )}
      </section>

      {/* Instrucción actual */}
      <AnimatePresence mode="wait">
        {banner && (
          <motion.div key={banner.title} initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} transition={{ duration: 0.2 }}
            className="flex items-center gap-3 p-3 rounded-[18px] text-white" style={{ background: banner.bg }}>
            <span className="w-10 h-10 rounded-xl flex items-center justify-center flex-none text-ink" style={{ background: banner.iconBg }}>{banner.icon}</span>
            <div className="min-w-0">
              <p className="m-0 text-sm font-extrabold leading-tight">{banner.title}</p>
              <p className="m-0 text-xs text-white/80 leading-snug">{banner.sub}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {mode === 'indoor' && (
        <div className="flex items-center justify-between gap-2.5 px-1">
          <div>
            <p className="m-0 text-[15px] font-extrabold">Edificio Norte · plano interior</p>
            <p className="m-0 text-xs text-muted">{viewFloor === stageFloor ? `Planta ${viewFloor} · tu ruta está aquí` : `Planta ${viewFloor} · tu ruta está en la planta ${stageFloor}`}</p>
          </div>
          <div className="flex gap-1 p-1 rounded-[14px] bg-chip">
            {[0, 1, 2].map((f) => (
              <button key={f} onClick={() => setViewFloor(f)} className={`relative w-10 h-[34px] rounded-[10px] text-[13px] font-extrabold ${viewFloor === f ? 'text-ink' : 'text-muted'}`}>
                {viewFloor === f && <motion.span layoutId="floor-pill" className="absolute inset-0 rounded-[10px] bg-white shadow-[0_2px_6px_rgba(22,20,43,0.12)]" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
                <span className="relative">P{f}</span>
                {f === stageFloor && indoorStage < 2 && <span className="absolute top-1 right-1.5 w-1.5 h-1.5 rounded-full bg-coral" />}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Lienzo del mapa: exterior ⇄ interior con transición de "entrar al edificio" */}
      <div className="relative w-full aspect-[370/380] rounded-[26px] bg-chip border border-[#E1DEEC] overflow-hidden">
        <AnimatePresence initial={false}>
          {mode !== 'indoor' ? (
            <motion.div key="outdoor" className="absolute inset-0"
              style={{ transformOrigin: '55% 17%' }}
              initial={{ opacity: 0, scale: 1 }} animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.8, filter: 'blur(4px)' }} transition={{ duration: 0.35, ease }}>
              <Outdoor mode={mode} selected={selected} onPlace={onPlace} interests={profile.interests} myClasses={myClasses} room={cls.room} />
              {mode === 'campus' && (
                <motion.button whileTap={{ scale: 0.97 }} onClick={() => setSheet('add')}
                  className="absolute left-2.5 bottom-2.5 h-11 pl-3 pr-4 rounded-[15px] bg-ink text-white text-[13px] font-extrabold flex items-center gap-1.5 shadow-[0_10px_22px_-8px_rgba(22,20,43,0.6)]">
                  <Plus size={18} strokeWidth={2.5} /> Añadir mi clase
                </motion.button>
              )}
            </motion.div>
          ) : (
            <motion.div key="indoor" className="absolute inset-0"
              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.35, ease, delay: 0.08 }}>
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={viewFloor} className="absolute inset-0"
                  initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={{ duration: 0.22 }}>
                  <Indoor floor={viewFloor} showRoute={viewFloor === stageFloor} arrived={indoorStage === 2} />
                </motion.div>
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {mode === 'route' && (
        <motion.button whileTap={{ scale: 0.98 }} onClick={enterBuilding}
          animate={routeStage >= 3 ? { boxShadow: ['0 0 0 0 rgba(255,106,85,.55)', '0 0 0 14px rgba(255,106,85,0)'] } : { boxShadow: '0 0 0 0 rgba(0,0,0,0)' }}
          transition={routeStage >= 3 ? { duration: 1.4, repeat: Infinity } : { duration: 0.2 }}
          className={`h-[54px] rounded-[18px] text-[15px] font-extrabold flex items-center justify-center gap-2 transition-colors ${routeStage >= 3 ? 'bg-coral text-ink' : 'bg-ink text-white'}`}>
          <DoorOpen size={18} /> He llegado al edificio
        </motion.button>
      )}
      {mode === 'indoor' && (
        <motion.button whileTap={{ scale: 0.98 }} onClick={indoorNext}
          className={`h-[54px] rounded-[18px] text-[15px] font-extrabold flex items-center justify-center gap-2 ${indoorStage === 1 ? 'bg-coral text-ink' : 'bg-ink text-white'}`}>
          {[<Layers size={18} key="l" />, <Check size={18} strokeWidth={2.5} key="c" />, <MapIcon size={18} key="m" />][indoorStage]}
          {['Ya estoy en la 2ª planta', 'He llegado al aula', 'Volver al mapa del campus'][indoorStage]}
        </motion.button>
      )}

      {mode !== 'campus' && (
        <ol className="m-0 p-2 list-none bg-white border border-chip rounded-[22px] flex flex-col">
          {steps.map((s, i) => (
            <li key={s.t} className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl transition-colors ${s.cur ? 'bg-brand-soft' : ''}`}>
              <span className={`w-7 h-7 rounded-full flex items-center justify-center flex-none text-xs font-extrabold ${s.done ? 'bg-ok text-white' : s.cur ? 'bg-brand text-white' : 'bg-chip text-muted'}`}>
                {s.done ? <Check size={14} strokeWidth={3} /> : s.cur ? <Icon name={s.icon} size={14} strokeWidth={2.5} /> : i + 1}
              </span>
              <span className={`flex-1 text-sm leading-snug ${s.cur ? 'font-extrabold' : 'font-semibold'} ${s.done ? 'text-muted' : ''}`}>{s.t}</span>
              <span className="text-xs font-bold text-muted whitespace-nowrap">{s.done ? 'Hecho' : s.d}</span>
            </li>
          ))}
        </ol>
      )}

      {mode === 'campus' && (
        <>
          <AnimatePresence>
            {sel && (
              <motion.div key={sel.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.2 }}
                className="flex items-center gap-3.5 p-3.5 rounded-[20px] bg-white border border-chip">
                <span className="w-[46px] h-[46px] rounded-[14px] bg-coral-soft text-coral-ink flex items-center justify-center flex-none"><Icon name={sel.icon} size={22} /></span>
                <div className="flex-1 min-w-0">
                  <p className="m-0 text-[15px] font-extrabold">{sel.name}</p>
                  <p className="m-0 text-[13px] text-body leading-snug">
                    {sel.desc}{myClasses.some((c) => c.building === sel.id) && ' · Tus clases: ' + myClasses.filter((c) => c.building === sel.id).map((c) => c.subject).join(', ')}
                  </p>
                </div>
                <span className="text-xs font-extrabold text-brand flex-none">{sel.walk}</span>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex flex-col gap-2.5">
            <div className="flex items-center gap-2 px-1">
              <span className="text-[13px] font-extrabold">Puntos de interés</span>
              <span className="flex items-center gap-1.5 text-xs text-muted"><span className="w-[9px] h-[9px] rounded-full bg-coral" />para ti</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {PLACES.map((p) => {
                const on = selected === p.id;
                return (
                  <button key={p.id} onClick={() => onPlace(p)}
                    className={`flex items-center gap-1.5 h-9 px-3 rounded-xl border-[1.5px] text-[13px] font-bold transition-colors ${on ? 'bg-ink text-white border-ink' : 'bg-white border-line'}`}>
                    <Icon name={p.icon} size={15} />{p.id === 'cafe' ? 'Cafetería · menú' : p.name}
                    {p.interest && profile.interests.includes(p.interest) && <span className="w-[7px] h-[7px] rounded-full bg-coral" />}
                  </button>
                );
              })}
            </div>
          </div>

          {myClasses.length > 0 && (
            <section className="bg-white border border-chip rounded-[22px] p-3.5 flex flex-col gap-2.5">
              <h3 className="m-0 text-[13px] font-extrabold">Mis clases en el mapa</h3>
              <AnimatePresence initial={false}>
                {myClasses.map((c) => (
                  <motion.div key={c.id} layout initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="flex items-center gap-3 overflow-hidden">
                    <span className="w-[38px] h-[38px] rounded-xl bg-ink text-white flex items-center justify-center text-xs font-extrabold flex-none">{abbr(c.subject)}</span>
                    <div className="flex-1 min-w-0">
                      <p className="m-0 text-sm font-bold">{c.subject}</p>
                      <p className="m-0 text-xs text-muted">{[PLACES.find((p) => p.id === c.building)?.name, c.room, `${c.day} ${c.time}`].filter(Boolean).join(' · ')}</p>
                    </div>
                    <button aria-label="Quitar" onClick={() => setMyClasses((cs) => cs.filter((x) => x.id !== c.id))} className="w-[34px] h-[34px] rounded-full bg-hair text-muted flex items-center justify-center"><X size={16} /></button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </section>
          )}
        </>
      )}

      <CafeSheet open={sheet === 'cafe'} onClose={() => setSheet(null)} />
      <AddClassSheet open={sheet === 'add'} onClose={() => setSheet(null)}
        onSave={(c) => { setMyClasses((cs) => [...cs, c]); setSelected(c.building); setSheet(null); flash('Clase añadida al mapa y al planner'); }} />
    </div>
  );
}

function Outdoor({ mode, selected, onPlace, interests, myClasses, room }) {
  return (
    <>
      {/* zonas verdes y calles */}
      <div className="absolute rounded-[18px] bg-[#DCE8D6]" style={box(14, 300, 100, 66)} />
      <div className="absolute rounded-[14px] bg-[#DCE8D6]" style={box(150, 346, 78, 40)} />
      <div className="absolute rounded-2xl bg-[#DCE8D6]" style={box(314, 14, 46, 120)} />
      <div className="absolute bg-white" style={box(0, 134, 370, 14)} />
      <div className="absolute bg-white" style={box(122, 0, 14, 380)} />
      <div className="absolute bg-white" style={box(234, 148, 12, 232)} />
      <div className="absolute bg-white" style={box(136, 252, 234, 12)} />
      <span className="absolute text-[9px] font-extrabold tracking-[0.1em] uppercase text-[#A6A2BC]" style={pt(30, 136)}>Av. Central</span>
      <span className="absolute text-[8px] font-extrabold tracking-[0.1em] uppercase text-[#A6A2BC]" style={pt(262, 254)}>Paseo Sur</span>

      {PLACES.map((p) => {
        const dest = p.id === 'norte';
        const pins = myClasses.filter((c) => c.building === p.id).slice(0, 2);
        return (
          <motion.button key={p.id} onClick={() => onPlace(p)} whileTap={mode === 'campus' ? { scale: 0.96 } : undefined}
            className={`absolute rounded-[14px] flex flex-col items-center justify-center gap-0.5 p-1 shadow-[0_2px_0_#DAD6E8] transition-[border-color] ${dest ? 'bg-brand-soft text-brand-ink' : 'bg-white text-ink'}`}
            style={{ ...box(p.x, p.y, p.w, p.h), border: selected === p.id ? '2px solid #16142B' : dest ? '2px solid #3D2FD6' : '1px solid #E1DEEC' }}>
            <Icon name={p.icon} size={dest ? 18 : 15} className="opacity-85" />
            <span className="text-[10.5px] font-extrabold leading-tight text-center">{p.short}</span>
            {p.interest && interests.includes(p.interest) && <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-coral border-[2.5px] border-chip" />}
            {pins.length > 0 && (
              <span className="absolute -top-2.5 -left-1 flex gap-1">
                {pins.map((c) => (
                  <motion.span key={c.id} initial={{ scale: 0, y: 6 }} animate={{ scale: 1, y: 0 }} transition={{ type: 'spring', stiffness: 500, damping: 22 }}
                    className="h-5 px-1.5 rounded-[7px] bg-ink text-white text-[10px] font-extrabold flex items-center shadow-[0_2px_6px_rgba(22,20,43,0.3)]">{abbr(c.subject)}</motion.span>
                ))}
              </span>
            )}
          </motion.button>
        );
      })}

      {/* etiqueta del aula de destino */}
      <div className="absolute -translate-x-1/2 -translate-y-full flex flex-col items-center pointer-events-none" style={pt(205, 108)}>
        <span className="px-2 py-1 rounded-lg bg-coral text-ink text-[11px] font-extrabold whitespace-nowrap">{room}</span>
        <span className="w-0.5 h-2 bg-coral" />
      </div>

      {mode === 'route' ? <RouteLayer points={ROUTE} duration={WALK_SECONDS} /> : <UserDot x={129} y={256} label="Estás aquí" />}
    </>
  );
}

function Indoor({ floor, showRoute, arrived }) {
  const f = FLOORS[floor];
  return (
    <>
      <div className="absolute border-[3px] border-body rounded-[10px] bg-surface" style={box(14, 14, 342, 358)} />
      <div className="absolute bg-white flex items-center justify-center text-[9px] font-extrabold tracking-[0.12em] uppercase text-[#A6A2BC]" style={box(22, 180, 326, 42)}>Pasillo principal</div>
      {f.rooms.map((r, i) => {
        const s = ROOM_STYLE[r.k];
        return (
          <div key={i} className="absolute rounded-lg flex flex-col items-center justify-center gap-0.5 text-center p-1"
            style={{ ...box(r.x, r.y, r.w, r.h), background: s.bg, border: s.bd, color: s.fg }}>
            <span className="font-display text-[17px] font-bold leading-none">{r.l}</span>
            <span className="text-[10px] font-bold leading-tight">{r.s}</span>
          </div>
        );
      })}
      {showRoute && f.route && (arrived
        ? <RouteLayer points={f.route} static />
        : <RouteLayer points={f.route} duration={floor === 0 ? 5 : 6} />)}
    </>
  );
}

/** Línea de ruta que se dibuja + punto del alumno que la recorre (Framer Motion, sin timers). */
function RouteLayer({ points, duration = 6, static: isStatic = false }) {
  const poly = points.map((p) => p.join(',')).join(' ');
  const seg = points.slice(1).map((p, i) => Math.hypot(p[0] - points[i][0], p[1] - points[i][1]));
  const total = seg.reduce((a, b) => a + b, 0);
  const times = [0, ...seg.map((_, i) => seg.slice(0, i + 1).reduce((a, b) => a + b, 0) / total)];
  const end = points[points.length - 1];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
      <polyline points={poly} fill="none" stroke="#3D2FD6" strokeOpacity="0.18" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
      <motion.polyline points={poly} fill="none" stroke="#3D2FD6" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round"
        initial={{ pathLength: isStatic ? 1 : 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.9, ease: 'easeOut' }} />
      <circle cx={end[0]} cy={end[1]} r="8" fill="#FF6A55" stroke="#fff" strokeWidth="3" />
      <motion.g
        initial={isStatic ? { x: end[0], y: end[1] } : { x: points[0][0], y: points[0][1] }}
        animate={isStatic ? { x: end[0], y: end[1] } : { x: points.map((p) => p[0]), y: points.map((p) => p[1]) }}
        transition={isStatic ? { duration: 0 } : { duration, times, ease: 'linear', delay: 0.4 }}>
        <motion.circle r="17" fill="#3D2FD6" animate={{ opacity: [0.25, 0.08, 0.25] }} transition={{ duration: 1.8, repeat: Infinity }} />
        <circle r="9" fill="#3D2FD6" stroke="#fff" strokeWidth="3.5" />
      </motion.g>
    </svg>
  );
}

function UserDot({ x, y, label }) {
  return (
    <div className="absolute w-0 h-0 pointer-events-none" style={pt(x, y)}>
      <motion.span className="absolute w-[22px] h-[22px] -left-[11px] -top-[11px] rounded-full bg-brand"
        animate={{ scale: [0.7, 2.6], opacity: [0.5, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut' }} />
      <span className="absolute w-5 h-5 -left-2.5 -top-2.5 rounded-full bg-brand border-[3.5px] border-white shadow-[0_3px_8px_rgba(22,20,43,0.35)]" />
      <span className="absolute left-3.5 -top-[11px] px-2 py-1 rounded-lg bg-ink text-white text-[11px] font-extrabold whitespace-nowrap">{label}</span>
    </div>
  );
}

function getBanner({ mode, routeStage, indoorStage, cls, minutesLeft }) {
  const dark = { bg: '#16142B', iconBg: '#FF6A55' };
  if (mode === 'route') {
    if (routeStage < 3) {
      const s = OUT_STEPS[routeStage];
      return { ...dark, title: s.t, sub: `${s.d} · paso ${routeStage + 1} de 3 · llegas en ${3 - routeStage} min`, icon: <Icon name={s.icon} size={20} strokeWidth={2.5} /> };
    }
    return { bg: '#3D2FD6', iconBg: '#FF6A55', title: 'Estás en la entrada del Edificio Norte', sub: 'Pulsa «He llegado al edificio» para ver el plano interior', icon: <DoorOpen size={20} /> };
  }
  if (mode === 'indoor') {
    if (indoorStage === 0) return { ...dark, title: 'Planta 0 · ve a la Escalera B', sub: 'Sube a la 2ª planta · 25 m hasta la escalera', icon: <Icon name="turnLeft" size={20} strokeWidth={2.5} /> };
    if (indoorStage === 1) return { ...dark, title: 'Planta 2 · sigue el pasillo hasta el fondo', sub: 'Aula 2.4, última puerta a la izquierda · 40 m', icon: <Icon name="nav" size={20} strokeWidth={2.5} /> };
    return { bg: '#0E7C52', iconBg: '#FFFFFF', title: `Has llegado al ${cls.room}`, sub: `${cls.subject} empieza en ${minutesLeft} min. ¡Buena clase!`, icon: <Check size={20} strokeWidth={3} /> };
  }
  return null;
}
