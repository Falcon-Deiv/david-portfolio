import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, Info, Search, Send, SquarePen } from 'lucide-react';
import { OverlayPortal } from './BottomSheet.jsx';
import { AV } from '../data/mock.js';
import { initials } from '../lib/dates.js';

const QUICK = ['¡Perfecto!', '¿A qué hora?', 'Voy de camino', 'Gracias'];
const avatarOf = (c) => (c.group ? ['#16142B', '#FFFFFF'] : AV[c.av % AV.length]);
const now = () => new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });

export default function Messages({ t, chats, setChats, flash }) {
  const [openId, setOpenId] = useState(null);
  const [q, setQ] = useState('');
  const [typing, setTyping] = useState(null);
  const unread = chats.filter((c) => c.unread > 0).length;
  const list = chats.filter((c) => !q.trim() || c.name.toLowerCase().includes(q.trim().toLowerCase()));

  const open = (id) => { setOpenId(id); setChats((cs) => cs.map((c) => (c.id === id ? { ...c, unread: 0 } : c))); };

  const send = (id, text) => {
    text = text.trim();
    if (!text) return;
    setChats((cs) => cs.map((c) => (c.id === id ? { ...c, msgs: [...c.msgs, { me: true, text, t: now() }], when: 'ahora' } : c)));
    // Respuesta simulada
    setTimeout(() => setTyping(id), 700);
    setTimeout(() => {
      setTyping(null);
      setChats((cs) => cs.map((c) => {
        if (c.id !== id) return c;
        const ri = c.ri || 0, r = c.replies[ri % c.replies.length];
        return { ...c, ri: ri + 1, msgs: [...c.msgs, { me: false, text: r.text, from: r.from, t: now() }], when: 'ahora' };
      }));
    }, 2300);
  };

  return (
    <div className="px-4 pt-[58px] flex flex-col gap-4">
      <header className="flex items-end justify-between gap-3 px-1">
        <div>
          <p className="m-0 text-[13px] font-semibold text-muted">{unread ? `${unread} chats sin leer` : 'Todo leído'}</p>
          <h1 className="m-0 font-display text-[30px] font-bold tracking-tight leading-tight">{t.nMsg}</h1>
        </div>
        <button onClick={() => flash('Elige a alguien de Activos ahora')} aria-label="Nuevo mensaje" className="w-[46px] h-[46px] rounded-full border border-line bg-white flex items-center justify-center"><SquarePen size={20} /></button>
      </header>

      <label className="relative">
        <Search size={18} className="absolute left-3.5 top-[13px] text-faint" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar"
          className="w-full h-11 rounded-[14px] bg-chip pl-[42px] pr-3.5 text-[15px] outline-none focus:ring-2 focus:ring-brand" />
      </label>

      <section className="flex flex-col gap-2.5">
        <h2 className="m-0 px-1 text-[13px] font-extrabold">Activos ahora</h2>
        <div className="flex gap-3.5 overflow-x-auto no-scrollbar px-1 pb-1">
          {chats.filter((c) => c.online).map((c) => {
            const av = avatarOf(c);
            return (
              <button key={c.id} onClick={() => open(c.id)} className="flex-none w-16 flex flex-col items-center gap-1.5">
                <span className="relative w-[62px] h-[62px] rounded-full p-[3px] bg-coral flex">
                  <span className="w-full h-full rounded-full border-[2.5px] border-surface flex items-center justify-center text-base font-extrabold" style={{ background: av[0], color: av[1] }}>{initials(c.name)}</span>
                  <span className="absolute right-0.5 bottom-0.5 w-[15px] h-[15px] rounded-full bg-ok border-[3px] border-surface" />
                </span>
                <span className="text-[11px] font-semibold text-body">{c.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </section>

      <ul className="m-0 p-0 list-none flex flex-col -mx-2">
        {list.map((c) => {
          const av = avatarOf(c), last = c.msgs[c.msgs.length - 1], un = c.unread > 0;
          const prefix = last.me ? 'Tú: ' : c.group && last.from ? last.from + ': ' : '';
          return (
            <li key={c.id}>
              <button onClick={() => open(c.id)} className="w-full flex items-center gap-3 px-2 py-2.5 rounded-2xl text-left hover:bg-white">
                <span className={`relative w-[54px] h-[54px] flex items-center justify-center text-[17px] font-extrabold flex-none ${c.group ? 'rounded-[18px]' : 'rounded-full'}`} style={{ background: av[0], color: av[1] }}>
                  {c.group ? '2B' : initials(c.name)}
                  {c.online && <span className="absolute right-0 bottom-0 w-[15px] h-[15px] rounded-full bg-ok border-[3px] border-surface" />}
                </span>
                <div className="flex-1 min-w-0">
                  <p className={`m-0 text-[15px] ${un ? 'font-extrabold' : 'font-semibold'}`}>{c.name}</p>
                  <p className={`m-0 text-[13px] truncate ${un ? 'font-bold text-ink' : 'text-muted'}`}>
                    {un && c.unread > 1 ? `${c.unread} mensajes nuevos` : prefix + last.text} · {c.when}
                  </p>
                </div>
                {un && <span className="w-2.5 h-2.5 rounded-full bg-brand flex-none" aria-label="Sin leer" />}
              </button>
            </li>
          );
        })}
        {list.length === 0 && <li className="p-6 text-center text-sm text-muted">Sin resultados</li>}
      </ul>

      <OverlayPortal>
        <AnimatePresence>
          {openId && (
            <ChatView key={openId} chat={chats.find((c) => c.id === openId)} typing={typing === openId}
              onBack={() => setOpenId(null)} onSend={(text) => send(openId, text)} flash={flash} />
          )}
        </AnimatePresence>
      </OverlayPortal>
    </div>
  );
}

function ChatView({ chat, typing, onBack, onSend, flash }) {
  const [draft, setDraft] = useState('');
  const scroller = useRef(null);
  const av = avatarOf(chat);

  // Mantener siempre visible el último mensaje
  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [chat.msgs.length, typing]);

  const submit = (text) => { onSend(text); setDraft(''); };

  return (
    <motion.div role="dialog" aria-label={`Chat con ${chat.name}`}
      initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'tween', duration: 0.28, ease: [0.32, 0.72, 0, 1] }}
      className="absolute inset-0 bg-white flex flex-col">
      <header className="pt-[54px] px-3 pb-2.5 flex items-center gap-2.5 border-b border-hair">
        <button onClick={onBack} aria-label="Volver" className="w-11 h-11 rounded-full flex items-center justify-center"><ArrowLeft size={20} /></button>
        <span className={`w-10 h-10 flex items-center justify-center text-sm font-extrabold flex-none ${chat.group ? 'rounded-[14px]' : 'rounded-full'}`} style={{ background: av[0], color: av[1] }}>
          {chat.group ? '2B' : initials(chat.name)}
        </span>
        <div className="flex-1 min-w-0">
          <p className="m-0 text-[15px] font-extrabold">{chat.name}</p>
          <p className={`m-0 text-xs ${typing || chat.online ? 'text-ok' : 'text-muted'}`}>{typing ? 'escribiendo…' : chat.online ? 'Activo ahora' : chat.sub}</p>
        </div>
        <button onClick={() => flash(chat.sub)} aria-label="Info" className="w-11 h-11 rounded-full flex items-center justify-center"><Info size={20} /></button>
      </header>

      <div ref={scroller} className="flex-1 overflow-y-auto px-3.5 pt-4 pb-3 flex flex-col no-scrollbar">
        <div className="flex flex-col items-center gap-1.5 pt-2 pb-5">
          <span className={`w-[76px] h-[76px] flex items-center justify-center text-[26px] font-extrabold ${chat.group ? 'rounded-3xl' : 'rounded-full'}`} style={{ background: av[0], color: av[1] }}>
            {chat.group ? '2B' : initials(chat.name)}
          </span>
          <p className="m-0 text-[17px] font-extrabold">{chat.name}</p>
          <p className="m-0 text-[13px] text-muted">{chat.sub} · UniWay</p>
        </div>
        {chat.msgs.map((m, i) => {
          const prev = chat.msgs[i - 1], next = chat.msgs[i + 1];
          const same = prev && prev.me === m.me && prev.from === m.from;
          const lastOfGroup = !next || next.me !== m.me || next.from !== m.from;
          return (
            <motion.div key={i} layout="position" initial={{ opacity: 0, y: 8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.2 }}
              className={`flex flex-col gap-0.5 ${m.me ? 'items-end' : 'items-start'} ${same ? 'mt-0.5' : 'mt-3'}`}>
              {chat.group && !m.me && !same && <span className="px-3 text-[11px] font-bold text-muted">{m.from}</span>}
              <div className={`max-w-[78%] px-3.5 py-2.5 text-[15px] leading-snug text-pretty ${m.me ? 'bg-brand text-white rounded-[20px_20px_6px_20px]' : 'bg-hair text-ink rounded-[20px_20px_20px_6px]'}`}>{m.text}</div>
              {lastOfGroup && <span className="px-1.5 text-[11px] text-faint">{m.t}</span>}
            </motion.div>
          );
        })}
        <AnimatePresence>
          {typing && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
              className="self-start mt-2.5 px-4 py-3.5 rounded-[20px_20px_20px_6px] bg-hair flex gap-1.5">
              {[0, 0.2, 0.4].map((d) => <span key={d} className="w-[7px] h-[7px] rounded-full bg-muted" style={{ animation: `blink 1.2s ${d}s infinite` }} />)}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="flex gap-1.5 px-3 py-1.5 overflow-x-auto no-scrollbar">
        {QUICK.map((qr) => (
          <button key={qr} onClick={() => submit(qr)} className="flex-none h-[34px] px-3 rounded-full border-[1.5px] border-line text-[13px] font-semibold">{qr}</button>
        ))}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); submit(draft); }} className="px-3 pt-1.5 pb-9 flex gap-2 items-center">
        <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Mensaje…"
          className="flex-1 h-[46px] rounded-full bg-hair px-[18px] text-[15px] outline-none focus:ring-2 focus:ring-brand" />
        <motion.button type="submit" whileTap={{ scale: 0.92 }} aria-label="Enviar"
          className={`w-[46px] h-[46px] rounded-full text-white flex items-center justify-center transition-colors ${draft.trim() ? 'bg-brand' : 'bg-[#C9C5DA]'}`}>
          <Send size={18} />
        </motion.button>
      </form>
    </motion.div>
  );
}
