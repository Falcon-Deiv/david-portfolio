import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bell, Globe, Heart, MapPin, MessageCircle, Plus, Send, Share2, Sparkles } from 'lucide-react';
import BottomSheet, { OverlayPortal } from './BottomSheet.jsx';
import { POSTS, AV, REC } from '../data/mock.js';
import { initials } from '../lib/dates.js';

const FILTERS = {
  Todo: () => true,
  Erasmus: (p) => p.erasmus,
  'Mi Facultad': (p) => p.fac === 'informatica',
};
const REC_KICKER = { d: 'Tu recomendación de hoy', w: 'Tu recomendación semanal', m: 'Tu recomendación del mes' };

export default function Feed({ t, profile, flash, onBell, goToMap }) {
  const [posts, setPosts] = useState(() => POSTS.map((p) => ({ ...p, liked: false, going: false, comments: [...p.comments] })));
  const [filter, setFilter] = useState('Todo');
  const [composeOpen, setComposeOpen] = useState(false);
  const firstName = profile.name.split(' ')[0];
  const recKey = profile.interests.find((i) => REC[i]) || 'gente';
  const rec = REC[recKey];

  const update = (id, fn) => setPosts((ps) => ps.map((p) => (p.id === id ? fn(p) : p)));
  const publish = (text, audience) => {
    const inf = /inform/i.test(profile.study);
    setPosts((ps) => [{ id: Date.now(), name: profile.name, handle: '@' + firstName.toLowerCase(), erasmus: profile.kind === 'erasmus',
      fac: inf ? 'informatica' : 'otra', facLabel: inf ? 'Fac. Informática' : profile.study, time: 'ahora', likes: 0, liked: false,
      text, comments: [], mine: true, audience }, ...ps]);
    setFilter('Todo');
    setComposeOpen(false);
    flash('Publicado en el muro');
  };

  return (
    <>
      <header className="sticky top-0 z-10 bg-surface/95 backdrop-blur-lg px-5 pt-[58px] pb-3 flex flex-col gap-3.5">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="m-0 text-[13px] font-semibold text-muted">Jueves 24 sep · {profile.study}</p>
            <h1 className="m-0 font-display text-[30px] font-bold tracking-tight leading-tight">{t.hello}, {firstName}</h1>
          </div>
          <button onClick={onBell} aria-label="Notificaciones" className="relative w-[46px] h-[46px] rounded-full border border-line bg-white flex items-center justify-center flex-none">
            <Bell size={20} />
            <span className="absolute top-2.5 right-[11px] w-[9px] h-[9px] rounded-full bg-coral border-2 border-white" />
          </button>
        </div>
        <div className="flex gap-2">
          {Object.keys(FILTERS).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className={`h-[38px] px-4 rounded-full border-[1.5px] text-sm font-bold flex items-center gap-1.5 transition-colors ${filter === f ? 'bg-ink text-white border-ink' : 'bg-white border-line'}`}>
              {f}<span className="text-xs opacity-70">{posts.filter(FILTERS[f]).length}</span>
            </button>
          ))}
        </div>
      </header>

      <div className="px-4 pt-1.5 flex flex-col gap-3">
        <section className="relative overflow-hidden bg-ink text-white rounded-3xl p-[18px] flex flex-col gap-2.5">
          <div className="absolute w-[150px] h-[150px] rounded-full bg-brand -right-[50px] -top-[60px]" />
          <span className="relative flex items-center gap-2 text-xs font-extrabold tracking-wider uppercase text-[#FF8A78]"><Sparkles size={16} /> {REC_KICKER[profile.freq]}</span>
          <h2 className="relative m-0 font-display text-[21px] font-bold leading-tight pr-10">{rec.title}</h2>
          <p className="relative m-0 text-sm text-white/80">{rec.meta}</p>
          <div className="relative flex items-center justify-between gap-2.5 mt-1">
            <span className="text-xs text-white/70">Por tu interés en: {t['i_' + recKey]}</span>
            <button onClick={goToMap} className="h-9 px-3.5 rounded-xl bg-coral text-ink text-[13px] font-extrabold flex items-center gap-1.5 flex-none"><MapPin size={16} /> Ver en el mapa</button>
          </div>
        </section>

        <AnimatePresence initial={false}>
          {posts.filter(FILTERS[filter]).map((p) => (
            <motion.div key={p.id} layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
              <PostCard post={p} profile={profile} onChange={(fn) => update(p.id, fn)} flash={flash} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <OverlayPortal>
        <motion.button onClick={() => setComposeOpen(true)} aria-label="Nueva publicación"
          initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }}
          whileHover={{ y: -2 }} whileTap={{ scale: 0.94 }} transition={{ duration: 0.2 }}
          className="absolute right-5 bottom-[106px] w-[62px] h-[62px] rounded-[22px] bg-coral text-ink flex items-center justify-center shadow-[0_14px_30px_-10px_rgba(210,68,47,0.75)]">
          <Plus size={28} strokeWidth={2.5} />
        </motion.button>
      </OverlayPortal>

      <ComposeSheet open={composeOpen} onClose={() => setComposeOpen(false)} me={profile.name} onPublish={publish} />
    </>
  );
}

function PostCard({ post: p, profile, onChange, flash }) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const av = p.mine ? ['#3D2FD6', '#FFFFFF'] : AV[p.av % AV.length];
  const send = () => {
    if (!draft.trim()) return;
    onChange((q) => ({ ...q, comments: [...q.comments, { name: profile.name, initials: initials(profile.name), text: draft.trim() }] }));
    setDraft('');
  };
  return (
    <article className="bg-white border border-chip rounded-[22px] px-4 pt-4 pb-2.5 flex flex-col gap-3">
      <div className="flex gap-3 items-start">
        <div className="w-11 h-11 rounded-full flex items-center justify-center font-extrabold text-[15px] flex-none" style={{ background: av[0], color: av[1] }}>{initials(p.name)}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-extrabold text-[15px]">{p.name}</span>
            <span className={`flex items-center gap-1 text-[11px] font-extrabold px-2 py-0.5 rounded-full ${p.erasmus ? 'bg-[#FFE3DE] text-[#A8321F]' : 'bg-brand-soft text-brand-ink'}`}>
              {p.erasmus && <Globe size={11} strokeWidth={2.5} />}{p.erasmus ? `Erasmus${p.country ? ' · ' + p.country : ''}` : 'Local'}
            </span>
          </div>
          <p className="m-0 text-[13px] text-muted">{p.handle} · {p.facLabel} · {p.time}</p>
        </div>
      </div>
      <p className="m-0 text-[15px] leading-relaxed text-pretty">{p.text}</p>

      {p.event && (
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-coral-soft">
          <div className="w-12 h-[52px] rounded-xl bg-white flex flex-col items-center justify-center flex-none">
            <span className="text-[10px] font-extrabold text-coral-ink uppercase">{p.event.mon}</span>
            <span className="font-display text-[22px] font-bold leading-none">{p.event.day}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="m-0 text-sm font-extrabold">{p.event.title}</p>
            <p className="m-0 text-xs text-body">{p.event.where}</p>
          </div>
          <button onClick={() => { onChange((q) => ({ ...q, going: !q.going })); if (!p.going) flash('Apuntada/o · ya está en tu planner'); }}
            className={`h-[34px] px-3 rounded-[11px] text-xs font-extrabold flex-none transition-colors ${p.going ? 'bg-ink text-white' : 'bg-coral text-ink'}`}>
            {p.going ? 'Apuntada/o' : 'Me apunto'}
          </button>
        </div>
      )}

      <div className="flex gap-0.5 -mx-2 pt-1.5 border-t border-hair">
        <ActionBtn onClick={() => onChange((q) => ({ ...q, liked: !q.liked }))} className={p.liked ? 'text-[#E5412B]' : 'text-muted'}>
          <motion.span animate={p.liked ? { scale: [1, 1.25, 1] } : { scale: 1 }} transition={{ duration: 0.25 }} className="flex">
            <Heart size={18} fill={p.liked ? 'currentColor' : 'none'} />
          </motion.span>
          {p.likes + (p.liked ? 1 : 0)}
        </ActionBtn>
        <ActionBtn onClick={() => setOpen(!open)} className={open ? 'text-brand' : 'text-muted'}><MessageCircle size={18} />{p.comments.length}</ActionBtn>
        <div className="flex-1" />
        <ActionBtn onClick={() => flash('Enlace copiado')} className="text-muted"><Share2 size={18} />Compartir</ActionBtn>
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }} className="overflow-hidden">
            <div className="flex flex-col gap-2.5 pt-1 pb-2">
              {p.comments.map((c, i) => (
                <div key={i} className="flex gap-2.5 items-start">
                  <div className="w-[30px] h-[30px] rounded-full bg-chip text-body flex items-center justify-center text-[11px] font-extrabold flex-none">{c.initials}</div>
                  <div className="flex-1 bg-surface rounded-[4px_14px_14px_14px] px-3 py-2">
                    <p className="m-0 text-xs font-extrabold">{c.name}</p>
                    <p className="m-0 text-sm leading-snug">{c.text}</p>
                  </div>
                </div>
              ))}
              <div className="flex gap-2">
                <input value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Escribe un comentario…"
                  className="flex-1 h-[42px] rounded-[14px] border-[1.5px] border-line px-3.5 text-sm outline-none focus:border-brand" />
                <button onClick={send} aria-label="Enviar" className="w-[42px] h-[42px] rounded-[14px] bg-brand text-white flex items-center justify-center"><Send size={18} /></button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}

const ActionBtn = ({ className = '', children, ...rest }) => (
  <button {...rest} className={`h-[38px] px-2.5 rounded-xl flex items-center gap-1.5 text-[13px] font-bold hover:bg-surface ${className}`}>{children}</button>
);

function ComposeSheet({ open, onClose, me, onPublish }) {
  const [text, setText] = useState('');
  const [aud, setAud] = useState('Todos');
  const ok = text.trim().length > 0;
  return (
    <BottomSheet open={open} onClose={onClose} title="Nueva publicación">
      <div className="flex flex-col gap-4">
        <div className="flex gap-3 items-start">
          <div className="w-10 h-10 rounded-full bg-brand text-white flex items-center justify-center font-extrabold text-sm flex-none">{initials(me)}</div>
          <textarea autoFocus value={text} onChange={(e) => setText(e.target.value)} maxLength={280}
            placeholder="¿Qué pasa por el campus? Pregunta, avisa o propón un plan…"
            className="flex-1 min-h-[120px] resize-none outline-none text-base leading-relaxed py-2 placeholder:text-faint" />
        </div>
        <div className="flex flex-col gap-2">
          <span className="text-xs font-extrabold tracking-wider uppercase text-muted">¿Quién lo ve?</span>
          <div className="flex gap-2">
            {['Todos', 'Erasmus', 'Mi Facultad'].map((a) => (
              <button key={a} onClick={() => setAud(a)} className={`h-9 px-3.5 rounded-full border-[1.5px] text-[13px] font-bold ${aud === a ? 'bg-brand text-white border-brand' : 'border-line'}`}>{a}</button>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-hair pt-3.5">
          <span className="text-[13px] font-semibold text-muted">{280 - text.length} caracteres</span>
          <button disabled={!ok} onClick={() => { onPublish(text.trim(), aud); setText(''); }}
            className={`h-[46px] px-5 rounded-[14px] text-white text-[15px] font-extrabold flex items-center gap-2 transition-colors ${ok ? 'bg-brand' : 'bg-[#C9C5DA]'}`}>
            <Send size={18} /> Publicar
          </button>
        </div>
      </div>
    </BottomSheet>
  );
}
