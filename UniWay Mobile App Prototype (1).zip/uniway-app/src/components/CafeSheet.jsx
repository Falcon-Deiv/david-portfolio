import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { UtensilsCrossed } from 'lucide-react';
import BottomSheet from './BottomSheet.jsx';
import { CAFE } from '../data/mock.js';

export default function CafeSheet({ open, onClose }) {
  const [tab, setTab] = useState('menu');
  return (
    <BottomSheet open={open} onClose={onClose} title="Cafetería Central" subtitle="Planta baja · 2 min andando" icon={<UtensilsCrossed size={22} />}>
      <div className="flex flex-col gap-3.5">
        <span className="self-start flex items-center gap-2 px-3 py-1.5 rounded-full bg-ok-soft text-ok-ink text-[13px] font-extrabold">
          <span className="w-2 h-2 rounded-full bg-ok" /> Abierto ahora · cierra a las 20:00
        </span>

        <dl className="m-0 rounded-[18px] bg-surface px-3.5 py-1">
          {CAFE.hours.map((h, i) => (
            <div key={h.d} className={`flex justify-between py-2.5 text-sm ${i < CAFE.hours.length - 1 ? 'border-b border-chip' : ''}`}>
              <dt className={h.today ? 'font-extrabold' : ''}>{h.d}</dt>
              <dd className={`m-0 ${h.today ? 'font-extrabold' : ''} ${h.h === 'Cerrado' ? 'text-[#A8321F]' : ''}`}>{h.h}</dd>
            </div>
          ))}
        </dl>

        <div className="flex gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1">
          {CAFE.tabs.map((c) => (
            <button key={c.id} onClick={() => setTab(c.id)}
              className={`relative flex-none h-9 px-3.5 rounded-full text-[13px] font-bold border-[1.5px] ${tab === c.id ? 'text-white border-ink' : 'border-line'}`}>
              {tab === c.id && <motion.span layoutId="cafe-tab" className="absolute inset-0 rounded-full bg-ink" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
              <span className="relative">{c.l}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.ul key={tab} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} transition={{ duration: 0.2 }}
            className="m-0 p-0 list-none flex flex-col gap-0.5">
            {CAFE.items[tab].map((it) => (
              <li key={it.n} className={`flex items-start gap-3 p-3 rounded-[14px] ${it.hl ? 'bg-coral-soft' : ''}`}>
                <div className="flex-1 min-w-0">
                  <p className="m-0 text-[15px] font-bold">{it.n}</p>
                  {it.d && <p className="m-0 text-[13px] text-muted leading-snug">{it.d}</p>}
                </div>
                <span className={`text-[15px] font-extrabold whitespace-nowrap ${it.p === 'Incluido' ? 'text-muted' : ''}`}>{it.p}</span>
              </li>
            ))}
          </motion.ul>
        </AnimatePresence>
      </div>
    </BottomSheet>
  );
}
