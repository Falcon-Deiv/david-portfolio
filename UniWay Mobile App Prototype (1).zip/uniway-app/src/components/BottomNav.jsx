import { motion } from 'framer-motion';
import { Home, Map, CalendarDays, MessageCircle } from 'lucide-react';

export default function BottomNav({ t, tab, setTab, unread }) {
  const items = [
    { id: 'feed', label: t.nFeed, Icon: Home },
    { id: 'map', label: t.nMap, Icon: Map },
    { id: 'planner', label: t.nPlan, Icon: CalendarDays },
    { id: 'messages', label: t.nMsg, Icon: MessageCircle },
  ];
  return (
    <nav className="absolute inset-x-0 bottom-0 z-20 h-[88px] pb-[env(safe-area-inset-bottom)] bg-white/95 backdrop-blur-xl border-t border-hair flex justify-around px-3 pt-2.5">
      {items.map(({ id, label, Icon }) => {
        const on = tab === id;
        return (
          <button key={id} onClick={() => setTab(id)} aria-current={on ? 'page' : undefined}
            className={`relative w-20 flex flex-col items-center gap-1 ${on ? 'text-brand' : 'text-muted'}`}>
            <span className="relative w-15 h-8 flex items-center justify-center">
              {on && (
                <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-2xl bg-brand-soft"
                  transition={{ type: 'spring', stiffness: 500, damping: 38 }} />
              )}
              <Icon size={22} strokeWidth={on ? 2.4 : 2} className="relative" />
            </span>
            <span className={`text-xs ${on ? 'font-extrabold' : 'font-semibold'}`}>{label}</span>
            {id === 'messages' && unread > 0 && (
              <span className="absolute -top-0.5 left-12 min-w-[18px] h-[18px] px-1 rounded-full bg-coral text-ink text-[11px] font-extrabold flex items-center justify-center border-2 border-white">
                {unread}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
}
