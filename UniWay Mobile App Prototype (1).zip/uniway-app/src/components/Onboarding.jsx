import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Check, Globe, GraduationCap, Sparkles } from 'lucide-react';
import { LANGS } from '../lib/i18n.js';
import { INTERESTS, EMPTY } from '../data/mock.js';
import { Icon } from '../lib/icons.jsx';

const STUDY_SUGGESTIONS = ['Ingeniería Informática', 'ADE', 'Medicina', 'Derecho', 'Psicología'];
const stepMotion = {
  initial: { opacity: 0, x: 24 }, animate: { opacity: 1, x: 0 }, exit: { opacity: 0, x: -24 },
  transition: { duration: 0.24, ease: 'easeOut' },
};

export default function Onboarding({ lang, setLang, t, onDone, onSkip }) {
  const [step, setStep] = useState(0); // 0 = bienvenida, 1-4 = preguntas
  const [p, setP] = useState({ ...EMPTY });
  const [saving, setSaving] = useState(-1); // -1 = no guardando; 0..3 progreso
  const set = (k, v) => setP((s) => ({ ...s, [k]: v }));

  const valid = [true, !!(p.name.trim() && p.study.trim()), !!(p.year && p.group), p.interests.length > 0, true][step];
  const hints = { 1: t.h1, 2: t.h2, 3: t.h3 };

  const next = () => {
    if (!valid) return;
    if (step < 4) return setStep(step + 1);
    setSaving(0);
    [600, 1150, 1700].forEach((ms, i) => setTimeout(() => setSaving(i + 1), ms));
    setTimeout(() => onDone(p), 2300);
  };

  if (saving >= 0) return <Saving t={t} name={p.name} progress={saving} />;
  if (step === 0) return <Welcome t={t} lang={lang} setLang={setLang} onStart={next} onSkip={onSkip} />;

  const shiftLabel = p.shift === 'pm' ? t.pm : t.am;
  const classPreview = [p.study || '—', [p.year, p.group].filter(Boolean).join(' '), shiftLabel].filter(Boolean).join(' · ');

  return (
    <div className="absolute inset-0 flex flex-col bg-surface">
      <header className="pt-[58px] px-5 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <button onClick={() => setStep(step - 1)} aria-label="Atrás" className="w-11 h-11 rounded-full border border-line bg-white flex items-center justify-center"><ArrowLeft size={20} /></button>
          <img src="/logo.jpg" alt="UniWay" className="w-11 h-11 invert mix-blend-multiply" />
          <span className="w-11 text-right text-[13px] font-bold text-muted">{step}/4</span>
        </div>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex-1 h-1.5 rounded-full bg-[#DAD6E8] overflow-hidden">
              <motion.div className="h-full bg-brand" initial={false} animate={{ width: i <= step ? '100%' : '0%' }} transition={{ duration: 0.3 }} />
            </div>
          ))}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pt-7 pb-6 no-scrollbar">
        <AnimatePresence mode="wait">
          <motion.div key={step} {...stepMotion} className="flex flex-col gap-6">
            {step === 1 && (<>
              <Heading kicker={t.k1} title={t.q1} sub={t.q1s} />
              <Field label={t.nameL}><TextInput value={p.name} onChange={(v) => set('name', v)} placeholder={t.nameP} /></Field>
              <Field label={t.studyL}><TextInput value={p.study} onChange={(v) => set('study', v)} placeholder={t.studyP} /></Field>
              <div className="flex flex-wrap gap-2 -mt-3">
                {STUDY_SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => set('study', s)}
                    className={`px-3 py-2 rounded-full border text-[13px] font-semibold transition ${p.study === s ? 'bg-brand-soft text-brand-ink border-brand' : 'bg-white text-body border-line'}`}>{s}</button>
                ))}
              </div>
              <Field label={t.kindL}>
                <Segmented value={p.kind} onChange={(v) => set('kind', v)} options={[
                  { id: 'local', label: t.tagNew, icon: <GraduationCap size={18} /> },
                  { id: 'erasmus', label: t.tagErasmus, icon: <Globe size={18} /> },
                ]} />
              </Field>
            </>)}

            {step === 2 && (<>
              <Heading kicker={t.k2} title={t.q2} sub={t.q2s} />
              <Field label={t.yearL}>
                <div className="grid grid-cols-4 gap-2">
                  {['1º', '2º', '3º', '4º'].map((y) => (
                    <button key={y} onClick={() => set('year', y)}
                      className={`h-[78px] rounded-[18px] border-[1.5px] flex flex-col items-center justify-center gap-0.5 transition ${p.year === y ? 'bg-brand text-white border-brand' : 'bg-white border-line'}`}>
                      <span className="font-display text-[28px] font-bold leading-none">{y}</span>
                      <span className="text-[11px] font-semibold opacity-80">{t.yearU}</span>
                    </button>
                  ))}
                </div>
              </Field>
              <Field label={t.groupL}>
                <div className="flex gap-2">
                  {['A', 'B', 'C', 'D'].map((g) => (
                    <button key={g} onClick={() => set('group', g)}
                      className={`w-14 h-12 rounded-[14px] border-[1.5px] text-base font-bold transition ${p.group === g ? 'bg-brand text-white border-brand' : 'bg-white border-line'}`}>{g}</button>
                  ))}
                </div>
              </Field>
              <Field label={t.shiftL}>
                <Segmented value={p.shift} onChange={(v) => set('shift', v)} options={[{ id: 'am', label: t.am }, { id: 'pm', label: t.pm }]} />
              </Field>
              <div className="flex items-center gap-3 px-4 py-3.5 rounded-[18px] bg-brand-soft text-brand-ink">
                <GraduationCap size={22} />
                <div className="flex flex-col gap-0.5">
                  <span className="text-[11px] font-extrabold tracking-wider uppercase">{t.yourClass}</span>
                  <span className="text-sm font-semibold">{classPreview}</span>
                </div>
              </div>
            </>)}

            {step === 3 && (<>
              <Heading kicker={t.k3} title={t.q3} sub={t.q3s} />
              <div className="flex flex-wrap gap-2.5">
                {INTERESTS.map((it) => {
                  const on = p.interests.includes(it.id);
                  return (
                    <motion.button key={it.id} whileTap={{ scale: 0.97 }}
                      onClick={() => set('interests', on ? p.interests.filter((x) => x !== it.id) : [...p.interests, it.id])}
                      className={`flex items-center gap-2.5 px-4 py-3 rounded-[18px] border-[1.5px] text-sm font-bold transition-colors ${on ? 'bg-brand text-white border-brand' : 'bg-white border-line'}`}>
                      {on ? <Check size={18} strokeWidth={3} /> : <Icon name={it.icon} size={18} />}
                      {t['i_' + it.id]}
                    </motion.button>
                  );
                })}
              </div>
              <p className="m-0 text-[13px] font-semibold text-muted">{p.interests.length ? `${p.interests.length} ${t.sel}` : t.none}</p>
            </>)}

            {step === 4 && (<>
              <Heading kicker={t.k4} title={t.q4} sub={t.q4s} />
              <div className="flex flex-col gap-2.5">
                {['d', 'w', 'm'].map((f) => {
                  const on = p.freq === f;
                  return (
                    <button key={f} onClick={() => set('freq', f)}
                      className={`flex items-center gap-3.5 p-4 rounded-[20px] border-[1.5px] bg-white text-left transition ${on ? 'border-brand' : 'border-line'}`}>
                      <span className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-none ${on ? 'border-brand' : 'border-[#C9C5DA]'}`}>
                        {on && <motion.span layoutId="freq-dot" className="w-3 h-3 rounded-full bg-brand" />}
                      </span>
                      <span className="flex flex-col gap-0.5">
                        <span className="text-base font-bold">{t['f_' + f]}</span>
                        <span className="text-[13px] text-muted">{t['fd_' + f]}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
              <div className="flex flex-col gap-2.5 p-4 rounded-[20px] bg-white border border-dashed border-[#D3CFE3]">
                <span className="text-[11px] font-extrabold tracking-wider uppercase text-muted">{t.summary}</span>
                <span className="text-[15px] font-bold">{p.name} · {classPreview}</span>
                <div className="flex flex-wrap gap-1.5">
                  {p.interests.map((i) => <span key={i} className="px-2.5 py-1 rounded-full bg-chip text-xs font-semibold text-body">{t['i_' + i]}</span>)}
                </div>
              </div>
            </>)}
          </motion.div>
        </AnimatePresence>
      </div>

      <footer className="px-5 pt-3 pb-11 flex flex-col gap-2.5 border-t border-chip">
        <motion.button whileTap={valid ? { scale: 0.98 } : undefined} onClick={next} disabled={!valid}
          className={`w-full h-[58px] rounded-[18px] text-white text-base font-extrabold flex items-center justify-center gap-2 transition-colors ${!valid ? 'bg-[#C9C5DA]' : step === 4 ? 'bg-coral' : 'bg-brand'}`}>
          {step === 4 ? t.begin : t.cont} {step === 4 ? <Sparkles size={18} /> : <ArrowRight size={20} />}
        </motion.button>
        <p className="m-0 text-center text-xs text-muted min-h-4">{valid ? (step === 4 ? t.later : '') : hints[step]}</p>
      </footer>
    </div>
  );
}

function Welcome({ t, lang, setLang, onStart, onSkip }) {
  return (
    <div className="absolute inset-0 bg-brand text-white flex flex-col px-6 pt-[66px] pb-12 overflow-hidden">
      <div className="absolute w-[420px] h-[420px] rounded-full bg-coral -right-[250px] top-[230px]" />
      <div className="absolute w-[300px] h-[300px] rounded-full border-2 border-white/15 -left-[150px] bottom-[210px]" />

      {/* Selector de idioma: lo primero que ve un estudiante Erasmus */}
      <div className="relative flex flex-col gap-2.5 p-3.5 rounded-3xl bg-white/10 border border-white/20">
        <span className="flex items-center gap-2 text-xs font-extrabold tracking-wider uppercase"><Globe size={16} /> {t.langTitle}</span>
        <div className="grid grid-cols-4 gap-2">
          {LANGS.map((l) => {
            const on = l.id === lang;
            return (
              <button key={l.id} onClick={() => setLang(l.id)} aria-pressed={on}
                className={`relative h-[62px] rounded-2xl border-[1.5px] flex flex-col items-center justify-center gap-0.5 transition-colors ${on ? 'text-brand border-white' : 'text-white border-white/35'}`}>
                {on && <motion.span layoutId="lang-pill" className="absolute inset-0 rounded-[14px] bg-white" transition={{ type: 'spring', stiffness: 500, damping: 36 }} />}
                <span className="relative font-display text-xl font-extrabold leading-none">{l.code}</span>
                <span className="relative text-[10.5px] font-semibold opacity-85">{l.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      <img src="/logo.jpg" alt="UniWay" className="relative w-[120px] h-[120px] mt-4 -ml-6 mix-blend-screen" />
      <div className="flex-1" />
      <div className="relative flex flex-wrap gap-2 mb-5">
        <span className="px-3.5 py-2 rounded-full bg-white text-ink text-[13px] font-bold -rotate-[4deg]">{t.tagNew}</span>
        <span className="px-3.5 py-2 rounded-full bg-coral text-ink text-[13px] font-bold rotate-[3deg]">{t.tagErasmus}</span>
        <span className="px-3.5 py-2 rounded-full border-[1.5px] border-white/60 text-[13px] font-bold -rotate-2">{t.tagCampus}</span>
      </div>
      <AnimatePresence mode="wait">
        <motion.div key={lang} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }} className="relative">
          <h1 className="m-0 font-display font-bold text-[42px] leading-none tracking-tight text-balance">{t.headline}</h1>
          <p className="mt-3 mb-0 text-[15px] leading-relaxed text-white/90 text-pretty">{t.sub}</p>
        </motion.div>
      </AnimatePresence>
      <div className="relative flex flex-col gap-3 mt-6">
        <motion.button whileTap={{ scale: 0.98 }} onClick={onStart} className="h-[58px] rounded-[18px] bg-white text-brand text-base font-extrabold flex items-center justify-center gap-2">
          {t.start} <ArrowRight size={20} />
        </motion.button>
        <button onClick={onSkip} className="text-sm font-semibold py-1.5">{t.have} <span className="underline underline-offset-4">{t.login}</span></button>
      </div>
    </div>
  );
}

function Saving({ t, name, progress }) {
  const steps = [t.sv1, t.sv2, t.sv3];
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 bg-brand text-white flex flex-col items-center justify-center gap-7 px-10">
      <div className="w-16 h-16 rounded-full border-[5px] border-white/20 border-t-coral animate-spin" />
      <h2 className="m-0 font-display text-[28px] font-bold tracking-tight text-center leading-tight">{t.saving}, {name.split(' ')[0]}</h2>
      <ul className="w-full flex flex-col gap-3 p-0 m-0 list-none">
        {steps.map((s, i) => {
          const done = progress > i;
          return (
            <li key={s} className={`flex items-center gap-3 text-[15px] font-semibold transition-opacity ${done || progress === i ? 'opacity-100' : 'opacity-45'}`}>
              <span className={`w-[26px] h-[26px] rounded-full flex items-center justify-center text-ink transition-colors ${done ? 'bg-coral' : 'bg-white/20'}`}>{done && <Check size={14} strokeWidth={3} />}</span>
              {s}
            </li>
          );
        })}
      </ul>
    </motion.div>
  );
}

const Heading = ({ kicker, title, sub }) => (
  <div className="flex flex-col gap-2">
    <span className="text-xs font-extrabold tracking-wider uppercase text-coral-ink">{kicker}</span>
    <h1 className="m-0 font-display font-bold text-[32px] leading-[1.05] tracking-tight">{title}</h1>
    <p className="m-0 text-[15px] leading-relaxed text-muted">{sub}</p>
  </div>
);
const Field = ({ label, children }) => (
  <label className="flex flex-col gap-2"><span className="text-[13px] font-bold">{label}</span>{children}</label>
);
const TextInput = ({ value, onChange, placeholder }) => (
  <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
    className="h-[54px] rounded-2xl border-[1.5px] border-line bg-white px-4 text-base outline-none placeholder:text-faint focus:border-brand focus:ring-4 focus:ring-brand-soft" />
);
export function Segmented({ value, onChange, options, id = 'seg' }) {
  return (
    <div className="grid gap-1.5 p-1.5 rounded-[18px] bg-chip" style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
      {options.map((o) => {
        const on = value === o.id;
        return (
          <button key={o.id} type="button" onClick={() => onChange(o.id)}
            className={`relative h-[46px] rounded-[14px] text-sm font-bold flex items-center justify-center gap-2 ${on ? 'text-ink' : 'text-muted'}`}>
            {on && <motion.span layoutId={`${id}-${options.map((x) => x.id).join('')}`} className="absolute inset-0 rounded-[14px] bg-white shadow-[0_2px_6px_rgba(22,20,43,0.12)]" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
            <span className="relative flex items-center gap-2">{o.icon}{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}
