import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { BookOpen, Calendar, Check, ChevronLeft, ChevronRight, Clock, Flag, GraduationCap, Sparkles, Zap } from 'lucide-react';
import { Segmented } from './Onboarding.jsx';
import { makePlan } from '../lib/planner.js';
import { TODAY, key, fromKey, addDays, mondayOf, WD, WDL, MON, MONL, fmt, cap } from '../lib/dates.js';
import { SCHEDULE, EVENTS, TYPES, PLACES } from '../data/mock.js';

const TYPE_ICON = { clase: GraduationCap, examen: Flag, evento: Calendar, estudio: BookOpen };
const LETTERS = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
const DAY_LETTER = ['', 'L', 'M', 'X', 'J', 'V', ''];
const SEMESTER_START = new Date(2026, 8, 14);
const SUGGESTIONS = [
  { label: 'BD · viernes · 2 h', text: 'Examen de Bases de Datos el viernes. Tengo 2 horas libres hoy.' },
  { label: 'Redes · martes · 3 h', text: 'Examen de Redes el martes a las 11. Tengo 3 horas libres hoy.' },
  { label: 'Discreta · lunes · 1 h', text: 'Examen de Matemática Discreta el lunes. Tengo 1 hora libre hoy.' },
];
const PHASES = ['Leyendo tu nota…', 'Detectando examen y tiempo libre…', 'Fragmentando el temario en bloques…'];

export default function Planner({ t, profile, plan, setPlan, myClasses, flash }) {
  const [view, setView] = useState('week');
  const [selKey, setSelKey] = useState(key(TODAY));
  const [month, setMonth] = useState([TODAY.getFullYear(), TODAY.getMonth()]);
  const [text, setText] = useState(SUGGESTIONS[0].text);
  const [phase, setPhase] = useState(-1); // -1 inactivo; 0-2 cargando
  const [done, setDone] = useState({});
  const sel = fromKey(selKey);

  // Todos los elementos de un día: horario + clases propias + eventos + plan de estudio
  const itemsFor = useMemo(() => (d) => {
    const k = key(d), wd = d.getDay(), out = [];
    if (d >= SEMESTER_START) (SCHEDULE[wd] || []).forEach((c) => out.push({ ...c, type: 'clase' }));
    myClasses.forEach((c) => {
      if (DAY_LETTER[wd] === c.day) out.push({ t: c.time.padStart(5, '0'), e: '', title: c.subject, type: 'clase',
        place: [c.room, PLACES.find((p) => p.id === c.building)?.name].filter(Boolean).join(' · ') });
    });
    (EVENTS[k] || []).forEach((e) => out.push(e));
    if (plan) {
      plan.days.forEach((day) => day.blocks.forEach((b) => {
        if (b.date === k) out.push({ t: fmt(b.s).padStart(5, '0'), e: fmt(b.e), title: b.topic, place: 'Smart Planner · ' + plan.subject, type: 'estudio' });
      }));
      if (key(plan.examDate) === k) out.push({ t: fmt(plan.examMin).padStart(5, '0'), e: fmt(plan.examMin + 120), title: 'Examen de ' + plan.subject, place: 'Aula 1.6 · Ed. Norte', type: 'examen' });
    }
    return out.sort((a, b) => a.t.localeCompare(b.t));
  }, [myClasses, plan]);

  const dots = (d) => [...new Set(itemsFor(d).map((i) => i.type))].slice(0, 3).map((ty) => TYPES[ty].dot);
  const pick = (d) => { setSelKey(key(d)); setMonth([d.getFullYear(), d.getMonth()]); };
  const shift = (dir) => {
    if (view === 'week') pick(addDays(sel, 7 * dir));
    else { const d = new Date(month[0], month[1] + dir, 1); setMonth([d.getFullYear(), d.getMonth()]); }
  };

  const runPlan = () => {
    if (phase >= 0) return;
    setPhase(0);
    setTimeout(() => setPhase(1), 600);
    setTimeout(() => setPhase(2), 1200);
    setTimeout(() => {
      const p = makePlan(text);
      setPlan(p); setDone({}); setPhase(-1); pick(TODAY);
      flash(`${p.count} bloques añadidos al calendario`);
    }, 1800);
  };

  const mon = mondayOf(sel), sun = addDays(mon, 6);
  const periodLabel = view === 'week'
    ? (mon.getMonth() === sun.getMonth() ? `${mon.getDate()} – ${sun.getDate()} ${MON[sun.getMonth()]}` : `${mon.getDate()} ${MON[mon.getMonth()]} – ${sun.getDate()} ${MON[sun.getMonth()]}`)
    : `${cap(MONL[month[1]])} ${month[0]}`;
  const agenda = itemsFor(sel);
  const allBlocks = plan ? plan.days.flatMap((d) => d.blocks) : [];
  const doneCount = allBlocks.filter((b) => done[b.id]).length;

  return (
    <div className="px-4 pt-[58px] flex flex-col gap-3.5">
      <header className="flex items-end justify-between gap-3 px-1">
        <div>
          <p className="m-0 text-[13px] font-semibold text-muted">{cap(MONL[sel.getMonth()])} {sel.getFullYear()} · {profile.study} {profile.year}</p>
          <h1 className="m-0 font-display text-[30px] font-bold tracking-tight leading-tight">{t.nPlan}</h1>
        </div>
        <div className="w-[170px]">
          <Segmented id="cal" value={view} onChange={(v) => { setView(v); setMonth([sel.getFullYear(), sel.getMonth()]); }} options={[{ id: 'week', label: 'Semana' }, { id: 'month', label: 'Mes' }]} />
        </div>
      </header>

      {/* Calendario */}
      <section className="bg-white border border-chip rounded-3xl p-3.5 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <RoundBtn onClick={() => shift(-1)} label="Anterior"><ChevronLeft size={18} /></RoundBtn>
          <span className="text-sm font-extrabold">{periodLabel}</span>
          <RoundBtn onClick={() => shift(1)} label="Siguiente"><ChevronRight size={18} /></RoundBtn>
        </div>

        <AnimatePresence mode="wait" initial={false}>
          {view === 'week' ? (
            <motion.div key={'w' + key(mon)} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }}
              className="grid grid-cols-7 gap-1">
              {LETTERS.map((l, i) => {
                const d = addDays(mon, i);
                return <DayCell key={l} d={d} letter={l} tall selKey={selKey} dots={dots(d)} onClick={() => pick(d)} />;
              })}
            </motion.div>
          ) : (
            <motion.div key={'m' + month.join('-')} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }}
              className="grid grid-cols-7 gap-0.5">
              {LETTERS.map((l) => <span key={l} className="text-center text-[11px] font-extrabold text-faint py-1">{l}</span>)}
              {Array.from({ length: (new Date(month[0], month[1], 1).getDay() + 6) % 7 }).map((_, i) => <span key={'b' + i} />)}
              {Array.from({ length: new Date(month[0], month[1] + 1, 0).getDate() }).map((_, i) => {
                const d = new Date(month[0], month[1], i + 1);
                return <DayCell key={i} d={d} selKey={selKey} dots={dots(d)} onClick={() => pick(d)} />;
              })}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="h-px bg-hair" />
        <div className="flex items-baseline justify-between px-1">
          <h2 className="m-0 text-[15px] font-extrabold">{selKey === key(TODAY) && 'Hoy · '}{cap(WDL[sel.getDay()])} {sel.getDate()} de {MONL[sel.getMonth()]}</h2>
          <span className="text-xs font-semibold text-muted">{agenda.length ? `${agenda.length} ${agenda.length === 1 ? 'elemento' : 'elementos'}` : ''}</span>
        </div>
        <AnimatePresence mode="wait" initial={false}>
          <motion.ul key={selKey} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
            className="m-0 p-0 list-none flex flex-col gap-1.5">
            {agenda.length === 0 && <li className="p-4 rounded-2xl bg-surface text-center text-sm text-muted">Día libre. Nada en tu agenda.</li>}
            {agenda.map((a, i) => {
              const ty = TYPES[a.type], I = TYPE_ICON[a.type];
              return (
                <li key={i} className={`flex items-center gap-3 p-2.5 rounded-2xl ${a.type === 'examen' ? 'bg-[#FFF5F3]' : 'bg-surface'}`}>
                  <div className="w-[46px] flex flex-col items-end flex-none">
                    <span className="text-[13px] font-extrabold">{a.t.replace(/^0/, '')}</span>
                    <span className="text-[11px] text-faint">{a.e}</span>
                  </div>
                  <span className="w-9 h-9 rounded-[11px] flex items-center justify-center flex-none" style={{ background: ty.bg, color: ty.fg }}><I size={17} /></span>
                  <div className="flex-1 min-w-0">
                    <p className="m-0 text-sm font-bold leading-snug">{a.title}</p>
                    <p className="m-0 text-xs text-muted">{a.place}</p>
                  </div>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full flex-none" style={{ background: ty.bg, color: ty.fg }}>{ty.label}</span>
                </li>
              );
            })}
          </motion.ul>
        </AnimatePresence>
      </section>

      {/* Smart Planner (estilo YourStep) */}
      <section className="relative overflow-hidden bg-ink text-white rounded-[26px] p-[18px] flex flex-col gap-3">
        <div className="absolute w-40 h-40 rounded-full bg-brand -right-[60px] -top-[70px]" />
        <div className="relative flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs font-extrabold tracking-wider uppercase text-[#FF8A78]"><Sparkles size={16} /> Smart Planner</span>
          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-white/10">estilo YourStep</span>
        </div>
        <h2 className="relative m-0 font-display text-[22px] font-bold leading-tight">Escribe como en tu agenda de papel</h2>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3}
          className="relative rounded-2xl border-[1.5px] border-white/20 bg-white/10 text-white px-3.5 py-3 text-[15px] leading-relaxed resize-none outline-none focus:border-coral" />
        <div className="relative flex flex-wrap gap-1.5">
          {SUGGESTIONS.map((s) => (
            <button key={s.label} onClick={() => setText(s.text)} className="px-3 py-1.5 rounded-full border border-white/25 text-white/90 text-xs font-semibold hover:bg-white/10">{s.label}</button>
          ))}
        </div>
        <motion.button whileTap={{ scale: 0.98 }} onClick={runPlan}
          className="relative h-[52px] rounded-2xl bg-coral text-ink text-[15px] font-extrabold flex items-center justify-center gap-2">
          {phase >= 0 ? <span className="w-4 h-4 rounded-full border-[2.5px] border-ink/25 border-t-ink animate-spin" /> : <Sparkles size={18} />}
          <AnimatePresence mode="wait" initial={false}>
            <motion.span key={phase} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.18 }}>
              {phase >= 0 ? PHASES[phase] : plan ? 'Reorganizar mi estudio' : 'Organizar mi estudio'}
            </motion.span>
          </AnimatePresence>
        </motion.button>
        {plan && phase < 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="relative flex flex-wrap gap-1.5">
            <Chip icon={<Flag size={13} />}>Examen: {plan.subject}</Chip>
            <Chip icon={<Calendar size={13} />}>{cap(WD[plan.examDate.getDay()])} {plan.examDate.getDate()} {MON[plan.examDate.getMonth()]} · {fmt(plan.examMin)}</Chip>
            <Chip icon={<Clock size={13} />}>{String(plan.hours).replace('.', ',')} h libres hoy</Chip>
            <Chip icon={<Zap size={13} />}>{plan.count} bloques</Chip>
          </motion.div>
        )}
      </section>

      <AnimatePresence>
        {plan && (
          <motion.section key={plan.subject + plan.count} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}
            className="bg-white border border-chip rounded-3xl p-4 flex flex-col gap-3.5">
            <div className="flex flex-col gap-2">
              <div className="flex items-baseline justify-between">
                <h2 className="m-0 text-base font-extrabold">Tu plan de estudio</h2>
                <span className="text-xs font-bold text-muted">{doneCount}/{allBlocks.length} bloques hechos</span>
              </div>
              <div className="h-1.5 rounded-full bg-hair overflow-hidden">
                <motion.div className="h-full rounded-full bg-brand" animate={{ width: `${allBlocks.length ? (doneCount / allBlocks.length) * 100 : 0}%` }} transition={{ duration: 0.3 }} />
              </div>
            </div>
            {plan.days.map((d, i) => (
              <div key={key(d.date)} className="flex flex-col gap-1.5">
                <p className="m-0 flex items-baseline gap-2">
                  <span className={`text-[13px] font-extrabold ${d.exam ? 'text-coral-ink' : ''}`}>{d.exam ? 'Día del examen' : i === 0 ? 'Hoy' : cap(WDL[d.date.getDay()])}</span>
                  <span className="text-xs text-muted">{WD[d.date.getDay()]} {d.date.getDate()} {MON[d.date.getMonth()]}</span>
                </p>
                {d.blocks.map((b) => {
                  const on = !!done[b.id];
                  return (
                    <button key={b.id} onClick={() => setDone((s) => ({ ...s, [b.id]: !s[b.id] }))}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-[14px] border border-chip text-left transition-colors ${on ? 'bg-surface' : 'bg-white'}`}>
                      <motion.span animate={{ backgroundColor: on ? '#12A26B' : 'rgba(0,0,0,0)', borderColor: on ? '#12A26B' : '#C9C5DA' }} transition={{ duration: 0.2 }}
                        className="w-6 h-6 rounded-lg border-2 text-white flex items-center justify-center flex-none">
                        {on && <Check size={13} strokeWidth={3.5} />}
                      </motion.span>
                      <div className="flex-1 min-w-0">
                        <p className={`m-0 text-sm font-bold ${on ? 'line-through text-faint' : ''}`}>{b.topic}</p>
                        <p className="m-0 text-xs text-muted">{fmt(b.s)} – {fmt(b.e)}</p>
                      </div>
                      <span className="text-[11px] font-extrabold px-2 py-0.5 rounded-full bg-amber-soft text-amber-ink flex-none">{b.mins} min</span>
                    </button>
                  );
                })}
                {d.exam && (
                  <div className="flex items-center gap-3 px-3 py-2.5 rounded-[14px] border border-[#FFD2CA] bg-[#FFF5F3]">
                    <span className="w-6 h-6 rounded-lg bg-[#E5412B] text-white flex items-center justify-center flex-none"><Flag size={12} strokeWidth={3} /></span>
                    <div className="flex-1">
                      <p className="m-0 text-sm font-bold text-[#A8321F]">Examen de {plan.subject}</p>
                      <p className="m-0 text-xs text-muted">{fmt(plan.examMin)} · Aula 1.6 · Ed. Norte</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
            <p className="m-0 flex items-center gap-2 px-3 py-2.5 rounded-[14px] bg-brand-soft text-brand-ink text-[13px] font-bold"><Calendar size={16} /> Bloques añadidos a tu calendario</p>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}

function DayCell({ d, letter, tall, selKey, dots, onClick }) {
  const k = key(d), on = k === selKey, today = k === key(TODAY);
  return (
    <button onClick={onClick}
      className={`relative flex flex-col items-center justify-center gap-1 rounded-2xl border-[1.5px] ${tall ? 'h-[74px]' : 'h-11 rounded-xl'} ${on ? 'text-white border-transparent' : today ? 'bg-brand-soft border-brand' : tall ? 'bg-surface border-transparent' : 'border-transparent'}`}>
      {on && <motion.span layoutId={tall ? 'day-week' : 'day-month'} className="absolute inset-0 rounded-[inherit] bg-brand" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
      {letter && <span className="relative text-[11px] font-bold opacity-75">{letter}</span>}
      <span className={`relative leading-none font-bold ${tall ? 'font-display text-xl' : 'text-sm'}`}>{d.getDate()}</span>
      <span className="relative flex gap-0.5 h-1.5">{dots.map((c) => <span key={c} className="w-1.5 h-1.5 rounded-full" style={{ background: c }} />)}</span>
    </button>
  );
}
const RoundBtn = ({ onClick, label, children }) => (
  <button onClick={onClick} aria-label={label} className="w-9 h-9 rounded-full bg-hair flex items-center justify-center">{children}</button>
);
const Chip = ({ icon, children }) => (
  <span className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-[10px] bg-white/10 text-xs font-bold">{icon}{children}</span>
);
