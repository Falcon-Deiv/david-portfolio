import { AnimatePresence, motion } from 'framer-motion';
import { Check, Navigation, X } from 'lucide-react';

/**
 * Pop-up de recordatorio de clase. Entra desde arriba con un spring suave
 * (ligero rebote) y sale hacia arriba con un fundido corto.
 */
export function ClassNotification({ open, t, subject, minutes, onOpen, onClose }) {
  const body = t.notifB.replace('{s}', subject).replace('{m}', minutes);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          role="alert"
          onClick={onOpen}
          initial={{ y: -120, opacity: 0, scale: 0.96 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: -80, opacity: 0, transition: { duration: 0.2, ease: 'easeIn' } }}
          transition={{ type: 'spring', stiffness: 420, damping: 26, mass: 0.8 }}
          drag="y" dragConstraints={{ top: 0, bottom: 0 }} dragElastic={{ top: 0.6, bottom: 0.1 }}
          onDragEnd={(_, info) => { if (info.offset.y < -40) onClose(); }}
          className="absolute left-2.5 right-2.5 top-[54px] z-50 flex items-start gap-3 p-3 pb-3.5 rounded-[26px] bg-white/90 backdrop-blur-2xl shadow-[0_18px_40px_-12px_rgba(22,20,43,0.45),0_0_0_1px_rgba(22,20,43,0.06)] cursor-pointer"
        >
          <img src="/logo.jpg" alt="" className="w-10 h-10 rounded-[11px] flex-none" />
          <div className="flex-1 min-w-0 flex flex-col gap-0.5">
            <div className="flex justify-between gap-2">
              <span className="text-xs font-extrabold tracking-wide uppercase text-muted">UniWay · {t.notifT}</span>
              <span className="text-xs text-faint">{t.now}</span>
            </div>
            <p className="m-0 text-[14.5px] font-semibold leading-snug text-ink text-pretty">{body}</p>
            <span className="mt-1.5 flex items-center gap-1.5 text-[13px] font-extrabold text-brand">
              <Navigation size={14} /> Ver ruta
            </span>
          </div>
          <button aria-label="Cerrar" onClick={(e) => { e.stopPropagation(); onClose(); }}
            className="w-7 h-7 flex-none rounded-full bg-ink/5 text-muted flex items-center justify-center">
            <X size={14} strokeWidth={2.5} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Confirmación breve encima de la barra inferior */
export function Snackbar({ message }) {
  return (
    <AnimatePresence>
      {message && (
        <motion.div key={message}
          initial={{ opacity: 0, y: 12, x: '-50%' }} animate={{ opacity: 1, y: 0, x: '-50%' }} exit={{ opacity: 0, y: 8, x: '-50%' }}
          transition={{ duration: 0.22, ease: 'easeOut' }}
          className="absolute left-1/2 bottom-[104px] z-40 flex items-center gap-2 px-4 py-3 rounded-2xl bg-ink text-white text-sm font-bold whitespace-nowrap shadow-[0_12px_30px_-10px_rgba(22,20,43,0.6)]">
          <Check size={16} strokeWidth={3} className="text-[#FF8A78]" /> {message}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
