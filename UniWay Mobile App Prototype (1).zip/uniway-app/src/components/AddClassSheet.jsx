import { useState } from 'react';
import { MapPin } from 'lucide-react';
import BottomSheet from './BottomSheet.jsx';
import { PLACES } from '../data/mock.js';
import { Icon } from '../lib/icons.jsx';

const DAYS = ['L', 'M', 'X', 'J', 'V'];
const TIMES = ['9:00', '10:30', '12:00', '15:00', '16:30', '18:00'];
const EMPTY = { subject: '', building: 'norte', room: '', day: 'L', time: '10:30' };

/** Vincula una asignatura a un edificio → pin personalizado en el mapa + entrada semanal en el Planner */
export default function AddClassSheet({ open, onClose, onSave }) {
  const [f, setF] = useState(EMPTY);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const ok = f.subject.trim().length > 0;
  const chip = (on) => `border-[1.5px] font-bold transition-colors ${on ? 'bg-brand text-white border-brand' : 'bg-white border-line'}`;

  const save = () => {
    if (!ok) return;
    onSave({ ...f, id: Date.now(), subject: f.subject.trim() });
    setF((s) => ({ ...EMPTY, building: s.building, day: s.day, time: s.time }));
  };

  return (
    <BottomSheet open={open} onClose={onClose} title="Añadir mi clase al mapa">
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-[1fr_110px] gap-2.5">
          <input value={f.subject} onChange={(e) => set('subject', e.target.value)} placeholder="Asignatura"
            className="min-w-0 h-[50px] rounded-[14px] border-[1.5px] border-line px-3.5 text-[15px] outline-none focus:border-brand" />
          <input value={f.room} onChange={(e) => set('room', e.target.value)} placeholder="Aula"
            className="min-w-0 h-[50px] rounded-[14px] border-[1.5px] border-line px-3.5 text-[15px] outline-none focus:border-brand" />
        </div>
        <fieldset className="m-0 p-0 border-0 flex flex-col gap-2">
          <legend className="text-xs font-extrabold tracking-wider uppercase text-muted mb-2">Edificio</legend>
          <div className="flex flex-wrap gap-1.5">
            {PLACES.filter((p) => p.id !== 'cafe').map((p) => (
              <button key={p.id} onClick={() => set('building', p.id)} className={`flex items-center gap-1.5 h-9 px-3 rounded-xl text-[13px] ${chip(f.building === p.id)}`}>
                <Icon name={p.icon} size={14} />{p.short}
              </button>
            ))}
          </div>
        </fieldset>
        <fieldset className="m-0 p-0 border-0 flex flex-col gap-2">
          <legend className="text-xs font-extrabold tracking-wider uppercase text-muted mb-2">Día y hora</legend>
          <div className="flex gap-1.5">
            {DAYS.map((d) => <button key={d} onClick={() => set('day', d)} className={`flex-1 h-10 rounded-xl text-sm ${chip(f.day === d)}`}>{d}</button>)}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {TIMES.map((tm) => <button key={tm} onClick={() => set('time', tm)} className={`h-9 px-3 rounded-xl text-[13px] ${chip(f.time === tm)}`}>{tm}</button>)}
          </div>
        </fieldset>
        <button disabled={!ok} onClick={save}
          className={`h-[54px] rounded-[18px] text-white text-[15px] font-extrabold flex items-center justify-center gap-2 transition-colors ${ok ? 'bg-brand' : 'bg-[#C9C5DA]'}`}>
          <MapPin size={16} /> Guardar y mostrar en el mapa
        </button>
      </div>
    </BottomSheet>
  );
}
