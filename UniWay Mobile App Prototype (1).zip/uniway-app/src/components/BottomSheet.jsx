import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';

const sheetSpring = { type: 'spring', stiffness: 380, damping: 38, mass: 0.9 };

/** Renderiza hijos en la capa de overlays del contenedor móvil (fuera del scroll y de las transiciones de pestaña) */
export function OverlayPortal({ children }) {
  const target = typeof document !== 'undefined' && document.getElementById('overlay-root');
  return target ? createPortal(children, target) : null;
}

/** Bottom sheet reutilizable: fondo con fundido + panel que sube desde abajo. Se puede cerrar arrastrando. */
export default function BottomSheet({ open, onClose, title, subtitle, icon, children, maxHeight = '86%' }) {
  const target = typeof document !== 'undefined' && document.getElementById('overlay-root');
  if (!target) return null;
  return createPortal(
    <AnimatePresence>
      {open && (
        <>
          <motion.div key="backdrop" onClick={onClose}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
            className="absolute inset-0 z-30 bg-ink/45" />
          <motion.div key="sheet" role="dialog" aria-modal="true"
            initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%', transition: { duration: 0.24, ease: [0.4, 0, 1, 1] } }}
            transition={sheetSpring}
            drag="y" dragConstraints={{ top: 0, bottom: 0 }} dragElastic={{ top: 0, bottom: 0.5 }}
            onDragEnd={(_, info) => { if (info.offset.y > 120 || info.velocity.y > 600) onClose(); }}
            style={{ maxHeight }}
            className="absolute inset-x-0 bottom-0 z-40 bg-white rounded-t-[30px] flex flex-col">
            <div className="px-5 pt-2.5 flex flex-col gap-3.5">
              <div className="w-10 h-[5px] rounded-full bg-[#DAD6E8] self-center" />
              <div className="flex items-center gap-3">
                {icon && <span className="w-12 h-12 rounded-[15px] bg-coral-soft text-coral-ink flex items-center justify-center flex-none">{icon}</span>}
                <div className="flex-1 min-w-0">
                  <h2 className="m-0 font-display text-[22px] font-bold tracking-tight leading-tight">{title}</h2>
                  {subtitle && <p className="m-0 text-[13px] text-muted">{subtitle}</p>}
                </div>
                <button onClick={onClose} aria-label="Cerrar" className="w-[38px] h-[38px] rounded-full bg-hair text-ink flex items-center justify-center">
                  <X size={18} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto px-5 pt-3.5 pb-10 no-scrollbar" onPointerDownCapture={(e) => e.stopPropagation()}>
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    target
  );
}
