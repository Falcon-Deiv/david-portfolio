import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Onboarding from './components/Onboarding.jsx';
import Feed from './components/Feed.jsx';
import Map from './components/Map.jsx';
import Planner from './components/Planner.jsx';
import Messages from './components/Messages.jsx';
import BottomNav from './components/BottomNav.jsx';
import { ClassNotification, Snackbar } from './components/Toast.jsx';
import { translate } from './lib/i18n.js';
import { classFor } from './lib/planner.js';
import { CHATS, DEMO } from './data/mock.js';

const tabMotion = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.22, ease: [0.25, 0.1, 0.25, 1] },
};

const NOTIF_DELAY_MS = 4000;
const CLASS_IN_MIN = 30;

export default function App() {
  // ── Estado global ─────────────────────────────────────────────
  const [lang, setLang] = useState('es');
  const [profile, setProfile] = useState(null);           // null = onboarding pendiente
  const [tab, setTab] = useState('feed');                 // feed | map | planner | messages
  const [chats, setChats] = useState(() => CHATS.map((c) => ({ ...c, msgs: [...c.msgs] })));
  const [myClasses, setMyClasses] = useState([]);         // clases añadidas al mapa (también salen en el Planner)
  const [plan, setPlan] = useState(null);                 // resultado del Smart Planner
  const [routeRequested, setRouteRequested] = useState(false); // true → el mapa inicia la ruta al montarse
  const [notif, setNotif] = useState(false);
  const [notifDone, setNotifDone] = useState(false);
  const [toast, setToast] = useState(null);
  const [classSec, setClassSec] = useState(CLASS_IN_MIN * 60);

  const t = useMemo(() => translate(lang), [lang]);
  const cls = useMemo(() => classFor(profile?.study), [profile?.study]);
  const minutesLeft = Math.ceil(classSec / 60);
  const unread = chats.filter((c) => c.unread > 0).length;
  const scrollRef = useRef(null);
  const toastTimer = useRef();

  const flash = (msg) => {
    clearTimeout(toastTimer.current);
    setToast(msg);
    toastTimer.current = setTimeout(() => setToast(null), 2400);
  };

  // Cuenta atrás de la próxima clase
  useEffect(() => {
    const id = setInterval(() => setClassSec((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, []);

  // Notificación simulada unos segundos después de entrar
  useEffect(() => {
    if (!profile || notifDone) return;
    const show = setTimeout(() => setNotif(true), NOTIF_DELAY_MS);
    return () => clearTimeout(show);
  }, [profile, notifDone]);

  useEffect(() => {
    if (!notif) return;
    const hide = setTimeout(() => setNotif(false), 14000);
    return () => clearTimeout(hide);
  }, [notif]);

  // Al cambiar de pestaña, volver arriba
  useEffect(() => { scrollRef.current?.scrollTo({ top: 0 }); }, [tab]);

  const openNotification = () => {
    setNotif(false);
    setNotifDone(true);
    setTab('map');
    setRouteRequested(true);
  };

  if (!profile) {
    return (
      <Shell>
        <Onboarding lang={lang} setLang={setLang} t={t}
          onDone={(p) => { setProfile(p); flash('Perfil guardado'); }}
          onSkip={() => setProfile({ ...DEMO })} />
      </Shell>
    );
  }

  const shared = { t, profile, cls, minutesLeft, flash };

  return (
    <Shell>
      <div ref={scrollRef} className="absolute inset-0 overflow-y-auto pb-28 no-scrollbar">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div key={tab} {...tabMotion}>
            {tab === 'feed' && <Feed {...shared} onBell={() => setNotif(true)} goToMap={() => setTab('map')} />}
            {tab === 'map' && (
              <Map {...shared} routeRequested={routeRequested} onRouteStarted={() => setRouteRequested(false)}
                myClasses={myClasses} setMyClasses={setMyClasses} />
            )}
            {tab === 'planner' && <Planner {...shared} plan={plan} setPlan={setPlan} myClasses={myClasses} />}
            {tab === 'messages' && <Messages {...shared} chats={chats} setChats={setChats} />}
          </motion.div>
        </AnimatePresence>
      </div>

      <BottomNav t={t} tab={tab} setTab={setTab} unread={unread} />

      <ClassNotification open={notif} t={t} subject={cls.subject} minutes={minutesLeft}
        onOpen={openNotification} onClose={() => { setNotif(false); setNotifDone(true); }} />
      <Snackbar message={toast} />
    </Shell>
  );
}

// Contenedor móvil: a pantalla completa en el teléfono, marco centrado en escritorio
function Shell({ children }) {
  return (
    <div className="min-h-full flex items-center justify-center sm:p-6">
      <div className="relative w-full h-[100dvh] sm:h-[874px] sm:max-h-[calc(100dvh-48px)] sm:w-[402px] bg-surface overflow-hidden sm:rounded-[44px] sm:shadow-[0_40px_80px_rgba(22,20,43,0.18),0_0_0_1px_rgba(22,20,43,0.08)]">
        {children}
        {/* Destino de los portales: bottom sheets por encima de la navegación */}
        <div id="overlay-root" className="absolute inset-0 z-30 pointer-events-none [&>*]:pointer-events-auto" />
      </div>
    </div>
  );
}
