# UniWay 2.0

App móvil (mobile-first) para estudiantes de nuevo ingreso y Erasmus.
Stack: **React 18 · Vite 6 · Tailwind CSS 4 · Lucide · Framer Motion**.

## Arrancar

```bash
# opción A — usar esta carpeta tal cual
cd uniway-app
npm install
npm run dev          # http://localhost:5173

# opción B — crear el proyecto desde cero y copiar /src, /public e index.html
npm create vite@latest uniway -- --template react
cd uniway
npm install framer-motion lucide-react
npm install -D tailwindcss @tailwindcss/vite
# sustituye vite.config.js, index.html, src/ y public/ por los de esta carpeta
npm run dev
```

Build de producción: `npm run build` → `dist/` · Previsualizar: `npm run preview`.

## Estructura

```
uniway-app/
├─ index.html
├─ package.json
├─ vite.config.js            # React + plugin de Tailwind 4
├─ public/
│  └─ logo.jpg
└─ src/
   ├─ main.jsx
   ├─ index.css              # @theme: colores (índigo/coral), tipografías
   ├─ App.jsx                # estado global, pestañas (AnimatePresence), notificación
   ├─ components/
   │  ├─ Onboarding.jsx      # selector de idioma + 4 pasos + "guardando"
   │  ├─ Feed.jsx            # muro social, filtros, comentarios, FAB + publicar
   │  ├─ Map.jsx             # campus → ruta → plano interior (P0/P1/P2)
   │  ├─ CafeSheet.jsx       # horarios + menú con precios (bottom sheet)
   │  ├─ AddClassSheet.jsx   # vincular asignatura a edificio (pin en el mapa)
   │  ├─ Planner.jsx         # calendario semana/mes + Smart Planner (YourStep)
   │  ├─ Messages.jsx        # DMs estilo Instagram + vista de chat
   │  ├─ BottomNav.jsx       # 4 pestañas con indicador animado
   │  ├─ BottomSheet.jsx     # modal inferior reutilizable + OverlayPortal
   │  └─ Toast.jsx           # notificación de clase (spring) + snackbar
   ├─ data/
   │  └─ mock.js             # posts, lugares, plantas, cafetería, chats, horario…
   └─ lib/
      ├─ i18n.js             # textos ES/EN/FR/DE + translate(lang)
      ├─ planner.js          # makePlan() — parser + fragmentación en bloques
      ├─ dates.js            # utilidades de fecha (fecha simulada: 24/09/2026)
      └─ icons.jsx           # nombre → icono de Lucide
```

## Animaciones (Framer Motion)

| Qué | Dónde | Cómo |
|---|---|---|
| Cambio de pestaña | `App.jsx` | `AnimatePresence mode="wait"` · fade + 8 px de desplazamiento · 0,22 s |
| Aviso "Tienes clase a las 12:00" | `Toast.jsx` | entra desde arriba con `spring` (stiffness 420, damping 26); se descarta deslizando hacia arriba |
| Exterior → interior | `Map.jsx` | el mapa exterior hace zoom (×1,8) hacia el Edificio Norte y se desvanece mientras el plano entra desde 0,9 (fundido cruzado, 0,35 s) |
| Cambio de planta | `Map.jsx` | slide vertical de 14 px · 0,22 s |
| Ruta | `Map.jsx` | `pathLength` 0→1 y el punto del alumno recorre la polilínea con keyframes proporcionales a cada tramo |
| Bottom sheets | `BottomSheet.jsx` | suben con `spring` sin rebote; se cierran arrastrando hacia abajo |
| Chat | `Messages.jsx` | la conversación entra deslizándose desde la derecha (0,28 s) |

## Siguientes pasos para producción

- Sustituir `data/mock.js` por una API (p. ej. React Query) y la fecha simulada de `lib/dates.js` por `new Date()`.
- Persistir el perfil/idioma (`localStorage` o backend) y extraer el estado global a un contexto o Zustand.
- Traducir también el contenido de Feed/Mapa/Planner/Mensajes (hoy solo onboarding, navegación, títulos y notificación).
- Notificaciones reales con la Push API / Capacitor si se empaqueta como app nativa.
